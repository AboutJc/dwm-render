#pragma once
#include <wrl.h>
#include <iostream>
class IShareBuffer {
public:
    virtual size_t         Size() const                           = 0;
    virtual unsigned char *Data() const                           = 0;
    virtual INT64          GetCombinationHandle() const           = 0;
    virtual HANDLE         GetSharedHandle() const                = 0;
    virtual bool           UploadData(void *buf, size_t buf_size) = 0;
    virtual bool           Download()                             = 0;
};

class IRSFactory {
public:
    static IRSFactory    *GetInstance();
    virtual bool          Init(INT64 ShareBufferHandle = 0)                                            = 0;
    virtual IShareBuffer *CreateShareBuffer(INT32 size)                                                = 0;
    virtual IShareBuffer *OpenShareBuffer(INT64 combinationHandle)                                     = 0;
    virtual INT64         MakeCombinationHandle(INT64 handle, INT32 device_id)                         = 0;
    virtual void          ExtractCombinationHandle(INT64 combination, INT64 *handle, INT32 *device_id) = 0;
};