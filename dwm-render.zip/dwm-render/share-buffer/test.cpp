#include "CShareBuffer.h"
#include <Windows.h>
#include <cstdio>
template <typename... Args>
void R3DbgPrint(const char *format, Args... args) {
#pragma warning(push)
#pragma warning(disable : 4996)
    char buffer[2500] = {'\0'};
    sprintf_s(buffer, 2500, "[share-buffer] ");
    sprintf_s(buffer + strlen(buffer), 2500 - strlen(buffer), format, args...);
    sprintf_s(buffer + strlen(buffer), 2500 - strlen(buffer), "%s", " \n");
    OutputDebugStringA(buffer);
    printf(buffer);
#pragma warning(pop)
}
#define Log(...) R3DbgPrint(__VA_ARGS__);
int main() {

    auto init = RSFactory::GetInstance().Init();

    Log("RSFactory::GetInstance().Init: %d", init);

    auto *buffer = RSFactory::GetInstance().CreateShareBuffer(0x100000);

    Log("RSFactory::GetInstance().CreateShareBuffer: %p", buffer);

    auto CombinationHandle = buffer->GetCombinationHandle();

    Log("buffer->GetCombinationHandle: %p", CombinationHandle);

    auto *shareBuffer = RSFactory::GetInstance().OpenShareBuffer(CombinationHandle);

    Log("RSFactory::GetInstance().OpenShareBuffer: %p", shareBuffer);

    if (buffer)
        delete buffer;
    if (shareBuffer)
        delete shareBuffer;

    system("pause");
    return 0;
}
