#include "CShareBuffer.h"
#include <d3d11.h>
#include <d3d10.h>
#include <dxgi.h>

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
class RSFactory;
class CShareBuffer : IShareBuffer {
    friend class RSFactory;
    template <typename T>
    using ComPtr                       = Microsoft::WRL::ComPtr<T>;
    CShareBuffer(const CShareBuffer &) = delete;
    CShareBuffer &operator=(const CShareBuffer &) = delete;

public:
    ~CShareBuffer();

    size_t         Size() const;
    unsigned char *Data() const;
    INT64          GetCombinationHandle() const;
    HANDLE         GetSharedHandle() const;
    bool           UploadData(void *buf, size_t buf_size);
    bool           Download();

private:
    CShareBuffer() {}
    unsigned char *pData = nullptr;
    size_t         sData = 0;

    ComPtr<IDXGIKeyedMutex>     pMutex            = 0;
    INT64                       combinationHandle = 0;
    HANDLE                      sharedHandle      = 0;
    ComPtr<ID3D11Device>        d3dDevice         = 0;
    ComPtr<ID3D11DeviceContext> d3dDeviceContext  = 0;
    ComPtr<ID3D11Buffer>        pSharedBuffer     = 0;
    ComPtr<ID3D11Buffer>        pLocalBuffer      = 0;
};

class RSFactory : IRSFactory {
    friend class IRSFactory;
    template <typename T>
    using ComPtr                 = Microsoft::WRL::ComPtr<T>;
    RSFactory(const RSFactory &) = delete;
    RSFactory &operator=(const RSFactory &) = delete;

public:
    bool              Init(INT64 ShareBufferHandle = 0);
    CShareBuffer     *CreateShareBuffer(INT32 size);
    CShareBuffer     *OpenShareBuffer(INT64 combinationHandle);
    INT64             MakeCombinationHandle(INT64 handle, INT32 device_id);
    void              ExtractCombinationHandle(INT64 combination, INT64 *handle, INT32 *device_id);
    ~RSFactory() {}

private:
    RSFactory() {}

private:
    INT32                       GpuDeviceId = 0;
    ComPtr<ID3D11Device>        d3dDevice;
    ComPtr<ID3D11DeviceContext> d3dDeviceContext;
    ComPtr<IDXGIDevice>         dxgiDevice;
    ComPtr<IDXGIAdapter>        dxgiAdapter;
};

IRSFactory *IRSFactory::GetInstance() {
    static RSFactory *instance = 0;
    if (!instance) {
        instance = new RSFactory{};
    }
    return instance;
}

size_t         CShareBuffer::Size() const { return sData; }
unsigned char *CShareBuffer::Data() const { return pData; }
INT64  CShareBuffer::GetCombinationHandle() const { return combinationHandle; }
HANDLE CShareBuffer::GetSharedHandle() const { return sharedHandle; }
bool           CShareBuffer::UploadData(void *buf, size_t buf_size) {
    if (buf_size > this->sData) {
        return false;
    }
    D3D11_MAPPED_SUBRESOURCE mapped_resource{};
    auto hr = d3dDeviceContext->Map(pLocalBuffer.Get(), 0, D3D11_MAP_READ_WRITE, 0, &mapped_resource);
    if (hr == S_OK) {
        if (buf && buf_size <= mapped_resource.DepthPitch) {
            memset(mapped_resource.pData, 0, mapped_resource.DepthPitch);
            memcpy(mapped_resource.pData, buf, buf_size);
        } else {
            memset(mapped_resource.pData, 0, mapped_resource.DepthPitch);
        }

        d3dDeviceContext->Unmap(pLocalBuffer.Get(), 0);
    }

    if (pMutex->AcquireSync(0, 1000) == S_OK) {
        d3dDeviceContext->CopyResource(pSharedBuffer.Get(), pLocalBuffer.Get());
        pMutex->ReleaseSync(0);
    } else {
        return false;
    }
    return true;
}

bool CShareBuffer::Download() {
    if (pMutex->AcquireSync(0, 1000) == S_OK) {
        d3dDeviceContext->CopyResource(pLocalBuffer.Get(), pSharedBuffer.Get());
        pMutex->ReleaseSync(0);
    } else {
        return false;
    }

    D3D11_MAPPED_SUBRESOURCE mapped_resource{};
    auto hr = d3dDeviceContext->Map(pLocalBuffer.Get(), 0, D3D11_MAP_READ_WRITE, 0, &mapped_resource);
    if (hr == S_OK) {
        if (!pData) {
            pData = new unsigned char[mapped_resource.DepthPitch];
        }
        memset(pData, 0, sData);
        memcpy(pData, mapped_resource.pData, sData);

        d3dDeviceContext->Unmap(pLocalBuffer.Get(), 0);
    } else {
        return false;
    }

    return true;
}

CShareBuffer::~CShareBuffer() {
    if (pData) {
        delete[] pData;
    }
}



INT64 RSFactory::MakeCombinationHandle(INT64 handle, INT32 device_id) {
    *((int *)(&handle) + 1) = (int)device_id;
    return handle;
}
void RSFactory::ExtractCombinationHandle(INT64 combination, INT64 *handle, INT32 *device_id) {
    if (device_id)
        *device_id = *((INT32 *)(&combination) + 1);
    if (handle) {
        *handle       = 0;
        UINT32 temp = *((UINT32 *)(&combination));
        *handle       = static_cast<INT64>(temp);
    }
}

bool RSFactory::Init(INT64 ShareBufferHandle) {

    if (ShareBufferHandle) {
        INT64 tempHandle = 0;
        ExtractCombinationHandle(ShareBufferHandle, (INT64 *)&tempHandle, (INT32 *)&GpuDeviceId);

        ComPtr<IDXGIFactory1> pFactory            = nullptr;
        ComPtr<IDXGIAdapter1> pRecommendedAdapter = nullptr;

        GUID IID_IDXGIFactory1 = {0x770aae78, 0xf26f, 0x4dba, 0xa8, 0x29, 0x25, 0x3c, 0x83, 0xd1, 0xb3, 0x87};
        auto hr                = CreateDXGIFactory1(IID_IDXGIFactory1, &pFactory);

        if (SUCCEEDED(hr)) {
            ComPtr<IDXGIAdapter1> pAdapter;
            UINT                  index = 0;
            while (pFactory->EnumAdapters1(index, &pAdapter) != DXGI_ERROR_NOT_FOUND) {
                DXGI_ADAPTER_DESC1 desc;
                pAdapter->GetDesc1(&desc);
                if (desc.DeviceId == GpuDeviceId) {
                    pRecommendedAdapter = pAdapter;
                }

                index++;
            }
        } else {
            return false;
        }

        if (!pRecommendedAdapter) {
            return false;
        }

        dxgiAdapter = pRecommendedAdapter;
    }

    UINT createDeviceFlags = 0;
    createDeviceFlags |= D3D11_CREATE_DEVICE_BGRA_SUPPORT;

    D3D_FEATURE_LEVEL       featureLevel;
    const D3D_FEATURE_LEVEL featureLevelArray[4] = {D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_1,
                                                    D3D_FEATURE_LEVEL_10_0, D3D_FEATURE_LEVEL_9_3};

    auto hr = S_OK;
    if (dxgiAdapter != nullptr) {
        D3D11CreateDevice(dxgiAdapter.Get(), D3D_DRIVER_TYPE_UNKNOWN, NULL, createDeviceFlags, featureLevelArray, 4, 7,
                          &d3dDevice, &featureLevel, &d3dDeviceContext);
    } else {
        D3D11CreateDevice(0, D3D_DRIVER_TYPE_HARDWARE, NULL, createDeviceFlags, featureLevelArray, 4, 7, &d3dDevice,
                          &featureLevel, &d3dDeviceContext);
    }
    if (hr != S_OK) {
        return false;
    }

    hr = d3dDevice.As(&dxgiDevice);

    if (hr != S_OK) {
        return false;
    }

    if (dxgiAdapter == nullptr) {
        hr = dxgiDevice->GetAdapter(&dxgiAdapter);
        if (hr != S_OK) {
            return false;
        }

        DXGI_ADAPTER_DESC adapter_desc{};
        hr = dxgiAdapter->GetDesc(&adapter_desc);
        if (hr != S_OK) {
            return false;
        }

        GpuDeviceId = adapter_desc.DeviceId;
    }

    if (hr != S_OK) {
        return false;
    }
    return true;
}
CShareBuffer *RSFactory::CreateShareBuffer(INT32 size) {
    D3D11_BUFFER_DESC share_desc{};
    share_desc.Usage          = D3D11_USAGE_DEFAULT;
    share_desc.ByteWidth      = size;
    share_desc.BindFlags      = 40;
    share_desc.CPUAccessFlags = 0;
    share_desc.MiscFlags      = D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX;

    ComPtr<ID3D11Buffer> pSharedBuffer = 0;

    auto hr = d3dDevice->CreateBuffer(&share_desc, NULL, &pSharedBuffer);
    if (hr != S_OK) {
        return 0;
    }

    D3D11_BUFFER_DESC
    local_desc                        = share_desc;
    local_desc.Usage                  = D3D11_USAGE_STAGING;
    local_desc.BindFlags              = 0;
    local_desc.CPUAccessFlags         = D3D11_CPU_ACCESS_WRITE | D3D11_CPU_ACCESS_READ;
    local_desc.MiscFlags              = 0;
    ComPtr<ID3D11Buffer> pLocalBuffer = 0;

    hr = d3dDevice->CreateBuffer(&local_desc, NULL, &pLocalBuffer);
    if (hr != S_OK) {
        return 0;
    }

    ComPtr<IDXGIResource> pResource = 0;

    hr = pSharedBuffer.As(&pResource);

    if (hr != S_OK) {
        return 0;
    }

    HANDLE
    SharedTextureHandle = 0;

    hr = pResource->GetSharedHandle(&(SharedTextureHandle));

    if (hr != S_OK) {
        return 0;
    }

    ComPtr<IDXGIKeyedMutex> pSharedKeyedMutex = 0;

    hr = pResource.As(&pSharedKeyedMutex);

    if (hr != S_OK) {
        return 0;
    }

    CShareBuffer *ret = new CShareBuffer();

    ret->sData             = size;
    ret->sharedHandle      = SharedTextureHandle;
    ret->d3dDevice         = this->d3dDevice;
    ret->d3dDeviceContext  = this->d3dDeviceContext;
    ret->pMutex            = pSharedKeyedMutex;
    ret->pSharedBuffer     = pSharedBuffer;
    ret->pLocalBuffer      = pLocalBuffer;
    ret->combinationHandle = MakeCombinationHandle((INT64)SharedTextureHandle, GpuDeviceId);


    unsigned char *initdata = new unsigned char[size];
    memset(initdata, 0, size);
    ret->UploadData(initdata, size);
    delete[] initdata;

    return ret;
}
CShareBuffer *RSFactory::OpenShareBuffer(INT64 combinationHandle) {
    if (!combinationHandle) {
        return nullptr;
    }

    INT32 deviceId   = 0;
    INT64 tempHandle = 0;
    ExtractCombinationHandle(combinationHandle, &tempHandle, &deviceId);
    if (deviceId != GpuDeviceId) {
        return nullptr;
    }

    HANDLE sharedHandle = (HANDLE)tempHandle;

    ComPtr<IDXGIResource> pResource = 0;
    GUID IID_IDXGIResource          = {0x035f3ab4, 0x482e, 0x4e50, 0xb4, 0x1f, 0x8a, 0x7f, 0x8b, 0xd8, 0x96, 0x0b};

    auto hr = d3dDevice->OpenSharedResource(sharedHandle, IID_IDXGIResource, &pResource);
    if (hr != S_OK) {
        return nullptr;
    }

    ComPtr<ID3D11Buffer> pSharedBuffer = 0;

    hr = pResource.As(&pSharedBuffer);

    if (hr != S_OK) {
        return nullptr;
    }

    ComPtr<IDXGIKeyedMutex> pMutex = 0;

    hr = pResource.As(&pMutex);

    if (hr != S_OK) {
        return nullptr;
    }

    D3D11_BUFFER_DESC share_desc;
    pSharedBuffer->GetDesc(&share_desc);

    D3D11_BUFFER_DESC local_desc      = share_desc;
    local_desc.Usage                  = D3D11_USAGE_STAGING;
    local_desc.BindFlags              = 0;
    local_desc.CPUAccessFlags         = D3D11_CPU_ACCESS_WRITE | D3D11_CPU_ACCESS_READ;
    local_desc.MiscFlags              = 0;
    ComPtr<ID3D11Buffer> pLocalBuffer = 0;

    hr = d3dDevice->CreateBuffer(&local_desc, NULL, &pLocalBuffer);
    if (hr != S_OK) {
        return nullptr;
    }

    CShareBuffer *ret = new CShareBuffer();

    ret->sData             = share_desc.ByteWidth;
    ret->sharedHandle      = sharedHandle;
    ret->d3dDevice         = this->d3dDevice;
    ret->d3dDeviceContext  = this->d3dDeviceContext;
    ret->pMutex            = pMutex;
    ret->pSharedBuffer     = pSharedBuffer;
    ret->pLocalBuffer      = pLocalBuffer;
    ret->combinationHandle = combinationHandle;
    return ret;
}