
#include "CShareBuffer.h"
#include "xorstr.hpp"
#include "imgui/imgui.h"
#include "RenderStream.hpp"
#include <vector>
#pragma comment(lib, "ntdll.lib")
#pragma comment(lib, "user32.lib")
#ifndef _WIN64
#include "EInterface.h"
#include "wow64/wow64ext.h"
#else
#include <winternl.h>
#endif // !_WIN64


/// <summary>
/// ���������д���� ����Ҫ�� ����Ҫ��
/// </summary>
/// <param name="DrawRectX">Ҫ��ʾ�����Ĳ��ֵ����Ͻ� X����</param>
/// <param name="DrawRectY">Ҫ��ʾ�����Ĳ��ֵ����Ͻ� Y����</param>
/// <param name="DrawRectW">��ʾ����</param>
/// <param name="DrawRectH">��ʾ�߶�</param>
/// <param name="buf">Ҫ���Ƶ�����</param>
/// <param name="win7">�Ƿ���win7</param>
/// <param name="draw_data">imgui����</param>
void PutImGuiRenderData(
	int DrawRectX,
	int DrawRectY,
	int DrawRectW,
	int DrawRectH,
	std::vector<char>& buf,
	bool win7 = false,
	struct ImDrawData* draw_data = ImGui::GetDrawData()
) {
	{
		int vtx_size = 0;
		for (int n = 0; n < draw_data->CmdListsCount; n++) {
			const ImDrawList* cmd_list = draw_data->CmdLists[n];
			vtx_size += (cmd_list->VtxBuffer.Size * sizeof(ImDrawVert));
		}
		std::vector<char> vtx_dst(vtx_size, 0);
		char* writePtr = vtx_dst.data();
		for (int n = 0; n < draw_data->CmdListsCount; n++) {
			const ImDrawList* cmd_list = draw_data->CmdLists[n];
			memcpy(writePtr, cmd_list->VtxBuffer.Data, cmd_list->VtxBuffer.Size * sizeof(ImDrawVert));
			writePtr += cmd_list->VtxBuffer.Size * sizeof(ImDrawVert);
			//memcpy(vtx_dst.data() + (n * cmd_list->VtxBuffer.Size), cmd_list->VtxBuffer.Data, cmd_list->VtxBuffer.Size * sizeof(ImDrawVert));
		}
		RenderStream::PutVert(buf, vtx_dst.data(), vtx_dst.size());
	}

	{
		int idx_size = 0;
		for (int n = 0; n < draw_data->CmdListsCount; n++) {
			const ImDrawList* cmd_list = draw_data->CmdLists[n];
			idx_size += (cmd_list->IdxBuffer.Size * sizeof(ImDrawIdx));
		}
		std::vector<char> idx_dst(idx_size, 0);
		char* writePtr = idx_dst.data();

		for (int n = 0; n < draw_data->CmdListsCount; n++) {
			const ImDrawList* cmd_list = draw_data->CmdLists[n];
			memcpy(writePtr, cmd_list->IdxBuffer.Data, cmd_list->IdxBuffer.Size * sizeof(ImDrawIdx));
			writePtr += cmd_list->IdxBuffer.Size * sizeof(ImDrawIdx);
			//memcpy(idx_dst.data() + (n * cmd_list->IdxBuffer.Size), cmd_list->IdxBuffer.Data, cmd_list->IdxBuffer.Size * sizeof(ImDrawIdx));


		}
		RenderStream::PutIdx(buf, idx_dst.data(), idx_dst.size());
	}
	{
		float L = draw_data->DisplayPos.x;
		float R = draw_data->DisplayPos.x + draw_data->DisplaySize.x;
		float T = draw_data->DisplayPos.y;
		float B = draw_data->DisplayPos.y + draw_data->DisplaySize.y;
		float mvp[4][4] =
		{
			{ 2.0f / (R - L),   0.0f,           0.0f,       0.0f },
			{ 0.0f,         2.0f / (T - B),     0.0f,       0.0f },
			{ 0.0f,         0.0f,           0.5f,       0.0f },
			{ (R + L) / (L - R),  (T + B) / (B - T),    0.5f,       1.0f },
		};

		RenderStream::DataVertexConstantBuffer VertexConstantBuffer{};
		memcpy(&(VertexConstantBuffer.mvp), mvp, sizeof(mvp));
		if (win7) {
			VertexConstantBuffer.vp.dx10.Width = (UINT)DrawRectW;
			VertexConstantBuffer.vp.dx10.Height = (UINT)DrawRectH;
			VertexConstantBuffer.vp.dx10.MinDepth = 0.0f;
			VertexConstantBuffer.vp.dx10.MaxDepth = 1.0f;
			VertexConstantBuffer.vp.dx10.TopLeftX = DrawRectX;
			VertexConstantBuffer.vp.dx10.TopLeftY = DrawRectY;
		}
		else {
			VertexConstantBuffer.vp.dx11.Width = (FLOAT)DrawRectW;
			VertexConstantBuffer.vp.dx11.Height = (FLOAT)DrawRectH;
			VertexConstantBuffer.vp.dx11.MinDepth = 0.0f;
			VertexConstantBuffer.vp.dx11.MaxDepth = 1.0f;
			VertexConstantBuffer.vp.dx11.TopLeftX = (FLOAT)DrawRectX;
			VertexConstantBuffer.vp.dx11.TopLeftY = (FLOAT)DrawRectY;
		}
		RenderStream::PutFunData(buf, VertexConstantBuffer);
	}

	{
		int global_vtx_offset = 0;
		int global_idx_offset = 0;
		ImVec2 clip_off = draw_data->DisplayPos;
		for (int n = 0; n < draw_data->CmdListsCount; n++)
		{
			const ImDrawList* cmd_list = draw_data->CmdLists[n];
			for (int cmd_i = 0; cmd_i < cmd_list->CmdBuffer.Size; cmd_i++)
			{
				const ImDrawCmd* pcmd = &cmd_list->CmdBuffer[cmd_i];

				RenderStream::DataSetScissorRects DataSetScissorRects{};
				DataSetScissorRects.NumRects = 1;
				if (win7) {
					DataSetScissorRects.rect.dx10 = { (LONG)(pcmd->ClipRect.x - clip_off.x), (LONG)(pcmd->ClipRect.y - clip_off.y), (LONG)(pcmd->ClipRect.z - clip_off.x), (LONG)(pcmd->ClipRect.w - clip_off.y) };
				}
				else {
					DataSetScissorRects.rect.dx11 = { (LONG)(pcmd->ClipRect.x - clip_off.x), (LONG)(pcmd->ClipRect.y - clip_off.y), (LONG)(pcmd->ClipRect.z - clip_off.x), (LONG)(pcmd->ClipRect.w - clip_off.y) };
				}
				RenderStream::PutFunData(buf, DataSetScissorRects);

				RenderStream::DataSetShaderResources DataSetShaderResources{};
				DataSetShaderResources.StartSlot = 0;
				DataSetShaderResources.NumViews = 1;
				DataSetShaderResources.TexID = (INT64)(pcmd->TextureId);
				RenderStream::PutFunData(buf, DataSetShaderResources);

				RenderStream::DataDrawIndexed DataDrawIndexed{};
				DataDrawIndexed.IndexCount = pcmd->ElemCount;
				DataDrawIndexed.StartIndexLocation = pcmd->IdxOffset + global_idx_offset;
				DataDrawIndexed.BaseVertexLocation = pcmd->VtxOffset + global_vtx_offset;
				RenderStream::PutFunData(buf, DataDrawIndexed);
			}
			global_idx_offset += cmd_list->IdxBuffer.Size;
			global_vtx_offset += cmd_list->VtxBuffer.Size;
		}

	}

}


extern "C" NTSYSAPI NTSTATUS WINAPI RtlGetVersion(
	PRTL_OSVERSIONINFOW lpVersionInformation
);
BOOL                     EnableDebugPriv();

#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)

bool                     iswin7 = false;
HANDLE                   dwmHandle;
INT64                    CommunicaHandle = 0;
int                      cx;
int                      cy;
int                      screenwidth_real;
int                      screenheight_real;
IShareBuffer *           CommunicaBuffer = 0;


EInterface BOOL init1() {
    // ʵ����Ŀ���治��Ҫ���
    {
        LoadLibraryA("d3d11.dll");
        LoadLibraryA("dxgi.dll");
        LoadLibraryA("user32.dll");
    }

    // ����Ҫ����, �����ǻ�ȡϵͳ�Ƿ���win7�� dwBuildNumber < 10240 ��˵����win7
    {
        RTL_OSVERSIONINFOW       osversion{};
        decltype(RtlGetVersion) *pRtlGetVersion =
            reinterpret_cast<decltype(RtlGetVersion) *>(GetProcAddress(GetModuleHandleA("ntdll.dll"), "RtlGetVersion"));
        pRtlGetVersion(&osversion);
        if (osversion.dwBuildNumber < 10240) {
            iswin7 = true;
        }
    }

    
    BOOL  enableDebugPriv = EnableDebugPriv();
#ifdef _DEBUG
    printf(u8"��������Ȩ�� %d\n", enableDebugPriv);
#endif // _DEBUG

    DWORD dwmPid = 0;
    GetWindowThreadProcessId(FindWindowA("Dwm", 0), &dwmPid);
#ifdef _DEBUG
    printf(u8"DWM ����ID %d\n", dwmPid);
#endif // _DEBUG
    dwmHandle = OpenProcess(PROCESS_ALL_ACCESS, false, dwmPid);
#ifdef _DEBUG
    printf(u8"DWM ���̾�� %p\n", dwmHandle);
#endif // _DEBUG


    return dwmHandle ? TRUE : FALSE;
}
EInterface VOID init2loop() {
#ifdef _WIN64
    typedef NTSTATUS(WINAPI * pNtQueryInformationProcess)(IN HANDLE               ProcessHandle,
                                                          IN DWORD                ProcessInformationClass,
                                                          OUT                     DWORD_PTR * ProcessInformation,
                                                          IN ULONG                ProcessInformationLength,
                                                          OUT PULONG ReturnLength OPTIONAL);
    pNtQueryInformationProcess NtQueryInformationProcess =
        (pNtQueryInformationProcess)GetProcAddress(GetModuleHandleA("ntdll.dll"), "NtQueryInformationProcess");
    PROCESS_BASIC_INFORMATION pbi          = {0};
    ULONG                     ReturnLength = 0;
    NtQueryInformationProcess(dwmHandle, 0, (DWORD_PTR *)&pbi, sizeof(pbi), &ReturnLength);
#ifdef _DEBUG
    printf(u8"DWM peb ��ַ %llx\n", pbi.PebBaseAddress);
#endif

    for (;;) {
        SIZE_T readSize = 0;
        BOOL   read     = ReadProcessMemory(dwmHandle, (LPVOID)((DWORD64)pbi.PebBaseAddress + 0xFF0), &CommunicaHandle,
                                      sizeof(CommunicaHandle), &readSize);
#ifdef _DEBUG
        printf(u8"ReadProcessMemory64 %lx\n", read);
        printf(u8"Communica Handle    %llx\n", CommunicaHandle);
#endif

        if (IRSFactory::GetInstance()->Init(CommunicaHandle)) {
            return;
        }
        Sleep(100);
    }

#else

    typedef struct _PROCESS_BASIC_INFORMATION64 {
        NTSTATUS ExitStatus;
        UINT32   Reserved0;
        UINT64   PebBaseAddress;
        UINT64   AffinityMask;
        UINT32   BasePriority;
        UINT32   Reserved1;
        UINT64   UniqueProcessId;
        UINT64   InheritedFromUniqueProcessId;
    } PROCESS_BASIC_INFORMATION64;

    typedef NTSTATUS(WINAPI * pfnNtWow64QueryInformationProcess64)(
        HANDLE ProcessHandle, UINT32 ProcessInformationClass, PVOID ProcessInformation, UINT32 ProcessInformationLength,
        UINT32 * ReturnLength);

    PROCESS_BASIC_INFORMATION64 pbi          = {0};
    UINT64                      ReturnLength = 0;

    HMODULE                             NtdllModule = GetModuleHandleA("ntdll.dll");
    pfnNtWow64QueryInformationProcess64 pNtWow64QueryInformationProcess64 =
        (pfnNtWow64QueryInformationProcess64)GetProcAddress(NtdllModule, "NtWow64QueryInformationProcess64");

    NTSTATUS Status =
        pNtWow64QueryInformationProcess64(dwmHandle, 0, &pbi, (UINT32)sizeof(pbi), (UINT32 *)&ReturnLength);
#ifdef _DEBUG
    printf(u8"DWM peb ��ַ %llx\n", pbi.PebBaseAddress);
#endif
    // 0xFF0

    for (;;) {
        SIZE_T readSize = 0;
        BOOL   read     = ReadProcessMemory64(dwmHandle, (DWORD64)pbi.PebBaseAddress + 0xFF0, &CommunicaHandle,
                                        sizeof(CommunicaHandle), &readSize);
#ifdef _DEBUG
        printf(u8"ReadProcessMemory64 %lx\n", read);
        printf(u8"Communica Handle    %llx\n", CommunicaHandle);
#endif

        if (IRSFactory::GetInstance()->Init(CommunicaHandle)) {
            return;
        }
        Sleep(100);
    }

#endif // _WIN64
}
EInterface BOOL init3() {

     // �� RSFactory ��ʼ����� ���� OpenCommunicaBuffer ��dwm�����õ� GPU ������
    CommunicaBuffer = IRSFactory::GetInstance()->OpenShareBuffer(CommunicaHandle);
#ifdef _DEBUG
    printf(u8"CommunicaBuffer* %p\n", CommunicaBuffer);
#endif // DEBUG

    // �������Ҫ ����������windows�Ļ���������Ҫ����д ��EnumDisplaySettings��ȡ������ʾ���� �� dm.dmPelsWidth ��
    // dm.dmPelsHeight GetSystemMetrics ��ȡ����ϵͳ������ķֱ��ʿ�SM_CXSCREEN ��SM_CYSCREEN
    // ���ǻ�ȡ������ֵ��һ�������� 2K��ʾ������ʵ�ֱ����� 2560 * 1440
    // ��GetSystemMetrics��ȡ���ı����ֵ��С��EnumDisplaySettings��ȡ��������ʵ�� ���� GetCursorPos
    // ��ȡ����������Ǹ��ݼٵ����ģ�������Ҫ�Ƚ� ��ȡ����� ���� GetSystemMetrics�õ��Ŀ��ߣ��ٳ���
    // EnumDisplaySettings�õ�����ʵ����
    DEVMODE dm;
    dm.dmSize        = sizeof(DEVMODE);
    dm.dmDriverExtra = 0;
    EnumDisplaySettings(NULL, ENUM_CURRENT_SETTINGS, &dm);
    cx                = dm.dmPelsWidth;
    cy                = dm.dmPelsHeight;
    screenwidth_real  = GetSystemMetrics(SM_CXSCREEN);
    screenheight_real = GetSystemMetrics(SM_CYSCREEN);

    // ��������������һ��
#ifdef _DEBUG
    printf(u8"��Ļ���� %d * %d\n", cx, cy);
    printf(u8"��Ļ���� %d * %d\n", screenwidth_real, screenheight_real);
#endif // DEBUG
    // imgui�ĳ�ʼ�� ���� ��imgui�ĳ�ʼ���������κεط���ֻ��Ҫ����һ�ξ��У�����Ҫ�� imgui dx11 hook
    // ������present����ã������������κδ��룬���� dx11 �޹�
    {
        ImGui::CreateContext();
        ImGui::StyleColorsDark();

        // ������أ�������û��� ���ڴ�������� GetGlyphRangesChineseFull������������ ���֡�
        ImFont *font = ImGui::GetIO().Fonts->AddFontFromFileTTF("MSYH.ttf", 16.0f, NULL,
                                                                ImGui::GetIO().Fonts->GetGlyphRangesChineseFull());
        // ����Ĵ���Ҫ������ļ����������һ�� ���̶�д�� ��Ҫ��
        ImGuiIO &      io     = ImGui::GetIO();
        unsigned char *pixels = 0;
        int            width = 0, height = 0;
        io.Fonts->GetTexDataAsRGBA32(&pixels, &width, &height);
        auto *            fontTexBuffer = IRSFactory::GetInstance()->CreateShareBuffer((width * height * 4) + 8);
        std::vector<char> fontdata((width * height * 4) + 8, 0);
        ((int *)fontdata.data())[0] = width;
        ((int *)fontdata.data())[1] = height;
        memcpy(fontdata.data() + 8, pixels, (width * height * 4));
        fontTexBuffer->UploadData(fontdata.data(), fontdata.size());
        io.Fonts->TexID = (ImTextureID)fontTexBuffer->GetCombinationHandle();
    }
#ifdef _DEBUG
    printf(u8"font load done\n");
#endif // DEBUG


    return TRUE;
}
EInterface void beginDraw() {
    //�ڻ���ѭ���ÿһ֡Ҫ����һ�� io.DisplaySize��һ��Ҫ�� EnumDisplaySettings ��õĿ���
    {
        auto &io         = ImGui::GetIO();
        io.DisplaySize.x = cx;
        io.DisplaySize.y = cy;
    }

    //ˢ��������� ��������Ҫ��  KEYDOWN KEYUP �ĺ��е� GetAsyncKeyState ��Ϊ��� syscall
    {
        auto &io = ImGui::GetIO();
        POINT info{};
        // ����� GetCursorPos ҲҪ�������syscall��������ԭ��������ֱ�ӵ��õ�GetCursorPosû�µĻ� �Ͳ���Ҫ��
        GetCursorPos(&info);
        io.MousePos = {((float)info.x / (float)screenwidth_real) * (float)cx,
                       ((float)info.y / (float)screenheight_real) * (float)cy};
        if (KEYDOWN(VK_LBUTTON))
            io.MouseDown[0] = true;
        if (KEYDOWN(VK_RBUTTON))
            io.MouseDown[1] = true;
        if (KEYDOWN(VK_MBUTTON))
            io.MouseDown[2] = true;
        if (KEYUP(VK_LBUTTON))
            io.MouseDown[0] = false;
        if (KEYUP(VK_RBUTTON))
            io.MouseDown[1] = false;
        if (KEYUP(VK_MBUTTON))
            io.MouseDown[2] = false;
    }

    // �̶�д�� ��ʼ����
    { ImGui::NewFrame(); }
}
EInterface void endDraw() {
    // �̶�д�� ��������
    {
        ImGui::Render();
        static std::vector<char> drawdata;
        drawdata.clear();
        // ������һ������ ��ûչʾ���� ͨ������ PutImGuiRenderData ��ǰ�ĸ�����������Կ�����ʾ���� 0, 0, cx, cy
        // ����ȫ����ʾ �ֱ��� ��ʾ�������Ͻ���������½�    ֻ����������ɵľ��� Ŀ����֧�� �����ڻ���������
        PutImGuiRenderData(0, 0, cx, cy, drawdata, iswin7);
        CommunicaBuffer->UploadData(drawdata.data(), drawdata.size());
    }
}
EInterface void destroyDraw() {
    // imgui ����ʼ�� ��һ�㲻��Ҫ ���Բ���
    ImGui::DestroyContext();
    if (dwmHandle) {
        CloseHandle(dwmHandle);
    }

}
#ifdef _WINDLL
BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved) {
    return TRUE;
}
#else
int main() {
    std::system("chcp 65001");
    if (!init1()) {
        printf(u8"��ʼ��ʧ��1\n");
        return -1;
    }

    init2loop();
    if (!init3()) {
#ifdef _DEBUG
        printf(u8"��ʼ��ʧ��3\n");
#endif // _DEBUG
        return -1;
    }

    while (!(GetAsyncKeyState(VK_END) & 0x8000)) {

        beginDraw();
        {

            auto &io = ImGui::GetIO();
            ImGui::GetBackgroundDrawList()->AddCircleFilled(io.MousePos, 10, 0xff0000ff);

            static bool show_another_window;
            ImGui::Begin("Another Window", &show_another_window);
            ImGui::Text("Hello from another window!");
            if (ImGui::Button("Close Me"))
                show_another_window = false;
            ImGui::End();

            ImGui::GetBackgroundDrawList()->AddText({200, 200}, 0xff00ffff, u8"͸�� ����");
            ImGui::GetBackgroundDrawList()->AddText({200, 250}, 0xff00ffff, u8"��� aim esp ");
            ImGui::GetBackgroundDrawList()->AddText({200, 300}, 0xff00ffff, u8"͸�� ���ϴ������");
            ImGui::GetBackgroundDrawList()->AddText({200, 350}, 0xff00ffff, u8"͸�� 4564564asfasfas");
            ImGui::GetBackgroundDrawList()->AddText({200, 400}, 0xff00ffff, u8"͸�� adasssssssssssss ��������");
        }
        endDraw();

        Sleep(10);
    }

    destroyDraw();

    std::system("pause");
    return 0;
}
#endif


BOOL EnableDebugPriv() {
    HANDLE           hToken{};
    LUID             sedebugnameValue{};
    TOKEN_PRIVILEGES tkp{};
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken)) {
        return FALSE;
    }

    if (!LookupPrivilegeValue(NULL, SE_DEBUG_NAME, &sedebugnameValue)) {
        CloseHandle(hToken);
        return FALSE;
    }
    tkp.PrivilegeCount           = 1;
    tkp.Privileges[0].Luid       = sedebugnameValue;
    tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

    if (!AdjustTokenPrivileges(hToken, FALSE, &tkp, sizeof(tkp), NULL, NULL)) {
        return FALSE;
    }
    CloseHandle(hToken);
    return TRUE;
}