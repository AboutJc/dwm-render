#pragma once
#include <Windows.h>
#ifdef _WINDLL
#define EInterface extern "C" __declspec(dllexport) 
#else 
#define EInterface
#endif

#define call_convention __stdcall

EInterface BOOL   init1();
EInterface VOID   init2loop();
EInterface BOOL   init3();
EInterface void   beginDraw();
EInterface void   endDraw();
EInterface void   destroyDraw();