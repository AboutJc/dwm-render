#pragma once
#include <vector>
#include <Windows.h>
namespace RenderStream {
typedef RECT D3D10_RECT;
typedef RECT D3D11_RECT;
typedef struct D3D10_VIEWPORT {
    INT   TopLeftX;
    INT   TopLeftY;
    UINT  Width;
    UINT  Height;
    FLOAT MinDepth;
    FLOAT MaxDepth;
} D3D10_VIEWPORT;
typedef struct D3D11_VIEWPORT {
    FLOAT TopLeftX;
    FLOAT TopLeftY;
    FLOAT Width;
    FLOAT Height;
    FLOAT MinDepth;
    FLOAT MaxDepth;
} D3D11_VIEWPORT;
enum class datatype : int {
    Unknown               = 0,
    DrawVert              = 1,
    DrawIdx               = 2,
    FunSetScissorRects    = 3,
    FunSetShaderResources = 4,
    FunDataDrawIndexed    = 5,
    VertexConstantBuffer  = 6,
};
static_assert(sizeof(datatype) == 4);

template <typename T, datatype _type>
struct TDataSection {
    inline const static datatype type = _type;
};

#pragma push_macro("DataSection")
#undef DataSection
#define DataSection(Section, type) struct Section : TDataSection<Section, type>
typedef struct dataheader {
    datatype type;
    int      size;
} dataheader_t;
DataSection(DataSetScissorRects, datatype::FunSetScissorRects) {
    UINT NumRects;
    union {
        D3D10_RECT dx10;
        D3D11_RECT dx11;
    } rect;
};
DataSection(DataSetShaderResources, datatype::FunSetShaderResources) {
    UINT   StartSlot;
    UINT   NumViews;
    UINT64 TexID;
};
DataSection(DataDrawIndexed, datatype::FunDataDrawIndexed) {
    UINT IndexCount;
    UINT StartIndexLocation;
    INT  BaseVertexLocation;
};
DataSection(DataVertexConstantBuffer, datatype::VertexConstantBuffer) {
    float mvp[4][4];
    union {
        D3D10_VIEWPORT dx10;
        D3D11_VIEWPORT dx11;
    } vp;
};

#pragma pop_macro("DataSection")

inline void PutVert(std::vector<char> &buf, char *verts, int size) {
    buf.resize(buf.size() + size + sizeof(dataheader), 0);
    char *pBuf                 = buf.data() + (buf.size() - (size + sizeof(dataheader)));
    ((dataheader *)pBuf)->size = size;
    ((dataheader *)pBuf)->type = datatype::DrawVert;
    memcpy((pBuf) + sizeof(dataheader), verts, size);
}

inline void PutIdx(std::vector<char> &buf, char *idxs, int size) {
    buf.resize(buf.size() + size + sizeof(dataheader), 0);
    char *pBuf                 = buf.data() + (buf.size() - (size + sizeof(dataheader)));
    ((dataheader *)pBuf)->size = size;
    ((dataheader *)pBuf)->type = datatype::DrawIdx;
    memcpy((pBuf) + sizeof(dataheader), idxs, size);
}

template <typename T>
inline void PutFunData(std::vector<char> &buf, T &FunData) {
    buf.resize(buf.size() + sizeof(T) + sizeof(dataheader), 0);
    char *pBuf                 = buf.data() + (buf.size() - (sizeof(T) + sizeof(dataheader)));
    ((dataheader *)pBuf)->size = sizeof(T);
    ((dataheader *)pBuf)->type = T::type;
    memcpy((pBuf) + sizeof(dataheader), &FunData, sizeof(T));
}
} // namespace RenderStream