#include "dwm.h"
#include "draw.h"
#include "RenderStream.hpp"
#include "lazy_importer.hpp"
#include "xorstr.hpp"
#include "Bypass.h"
#include "CShareBuffer.h"
#include "CImDataRender.h"
namespace draw {
IShareBuffer *CommunicaBuffer = nullptr;
bool          init() {

    auto *RSFactory = IRSFactory::GetInstance();
    RSFactory->Init();
    CommunicaBuffer = RSFactory->CreateShareBuffer(0x100000);
    if (CommunicaBuffer) {
        INT64 peb_data     = __readgsqword(0x60) + 0xFF0;
        *(INT64 *)peb_data = CommunicaBuffer->GetCombinationHandle();
        MSG_LOG("peb_data          0x%llx", peb_data);
        MSG_LOG("CombinationHandle 0x%llx", CommunicaBuffer->GetCombinationHandle());
        return true;
    }
    return false;
}

void                     draw_call() {
    extern NTSYSAPI NTSTATUS  RtlGetVersion(PRTL_OSVERSIONINFOW lpVersionInformation);
    static RTL_OSVERSIONINFOW osversion{};
    if (!osversion.dwBuildNumber) {
        LI_FN(RtlGetVersion)(&osversion);
    }


    CommunicaBuffer->Download();

    if (osversion.dwBuildNumber >= 10240) {
        IImDataRender::GetInstance(0xD3D11)->RenderData(CommunicaBuffer->Data(), CommunicaBuffer->Size());
    } else {
        IImDataRender::GetInstance(0xD3D10)->RenderData(CommunicaBuffer->Data(), CommunicaBuffer->Size());
    }
}
}; // namespace draw
