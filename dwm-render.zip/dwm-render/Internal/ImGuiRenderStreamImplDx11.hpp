#pragma once
#include <d3d11.h>
#include <dxgi.h>
#include <string>
#include <vector>
#include <unordered_map>
#include "xorstr.hpp"
#include "RenderStream.hpp"
inline const unsigned char imgui_pixel_shader[] =
{
     68,  88,  66,  67, 156, 131,
    174, 203, 172,  47, 184, 213,
    201,  80,  81, 217,  17,  39,
     38,  74,   1,   0,   0,   0,
     64,   3,   0,   0,   6,   0,
      0,   0,  56,   0,   0,   0,
    204,   0,   0,   0, 124,   1,
      0,   0, 248,   1,   0,   0,
    152,   2,   0,   0,  12,   3,
      0,   0,  65, 111, 110,  57,
    140,   0,   0,   0, 140,   0,
      0,   0,   0,   2, 255, 255,
    100,   0,   0,   0,  40,   0,
      0,   0,   0,   0,  40,   0,
      0,   0,  40,   0,   0,   0,
     40,   0,   1,   0,  36,   0,
      0,   0,  40,   0,   0,   0,
      0,   0,   1,   2, 255, 255,
     31,   0,   0,   2,   0,   0,
      0, 128,   0,   0,  15, 176,
     31,   0,   0,   2,   0,   0,
      0, 128,   1,   0,   3, 176,
     31,   0,   0,   2,   0,   0,
      0, 144,   0,   8,  15, 160,
     66,   0,   0,   3,   0,   0,
     15, 128,   1,   0, 228, 176,
      0,   8, 228, 160,   5,   0,
      0,   3,   0,   0,  15, 128,
      0,   0, 228, 128,   0,   0,
    228, 176,   1,   0,   0,   2,
      0,   0,  15, 128,   0,   0,
    228, 128,   1,   0,   0,   2,
      0,   8,  15, 128,   0,   0,
    228, 128, 255, 255,   0,   0,
     83,  72,  68,  82, 168,   0,
      0,   0,  64,   0,   0,   0,
     42,   0,   0,   0,  90,   0,
      0,   3,   0,  96,  16,   0,
      0,   0,   0,   0,  88,  24,
      0,   4,   0, 112,  16,   0,
      0,   0,   0,   0,  85,  85,
      0,   0,  98,  16,   0,   3,
    242,  16,  16,   0,   1,   0,
      0,   0,  98,  16,   0,   3,
     50,  16,  16,   0,   2,   0,
      0,   0, 101,   0,   0,   3,
    242,  32,  16,   0,   0,   0,
      0,   0, 104,   0,   0,   2,
      1,   0,   0,   0,  69,   0,
      0,   9, 242,   0,  16,   0,
      0,   0,   0,   0,  70,  16,
     16,   0,   2,   0,   0,   0,
     70, 126,  16,   0,   0,   0,
      0,   0,   0,  96,  16,   0,
      0,   0,   0,   0,  56,   0,
      0,   7, 242,   0,  16,   0,
      0,   0,   0,   0,  70,  14,
     16,   0,   0,   0,   0,   0,
     70,  30,  16,   0,   1,   0,
      0,   0,  54,   0,   0,   5,
    242,  32,  16,   0,   0,   0,
      0,   0,  70,  14,  16,   0,
      0,   0,   0,   0,  62,   0,
      0,   1,  83,  84,  65,  84,
    116,   0,   0,   0,   4,   0,
      0,   0,   1,   0,   0,   0,
      0,   0,   0,   0,   3,   0,
      0,   0,   1,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   1,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      1,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   1,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
     82,  68,  69,  70, 152,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   2,   0,
      0,   0,  28,   0,   0,   0,
      0,   4, 255, 255,   4,   1,
      0,   0, 110,   0,   0,   0,
     92,   0,   0,   0,   3,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      1,   0,   0,   0,   0,   0,
      0,   0, 101,   0,   0,   0,
      2,   0,   0,   0,   5,   0,
      0,   0,   4,   0,   0,   0,
    255, 255, 255, 255,   0,   0,
      0,   0,   1,   0,   0,   0,
     12,   0,   0,   0, 115,  97,
    109, 112, 108, 101, 114,  48,
      0, 116, 101, 120, 116, 117,
    114, 101,  48,   0,  77, 105,
     99, 114, 111, 115, 111, 102,
    116,  32,  40,  82,  41,  32,
     72,  76,  83,  76,  32,  83,
    104,  97, 100, 101, 114,  32,
     67, 111, 109, 112, 105, 108,
    101, 114,  32,  49,  48,  46,
     49,   0, 171, 171,  73,  83,
     71,  78, 108,   0,   0,   0,
      3,   0,   0,   0,   8,   0,
      0,   0,  80,   0,   0,   0,
      0,   0,   0,   0,   1,   0,
      0,   0,   3,   0,   0,   0,
      0,   0,   0,   0,  15,   0,
      0,   0,  92,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   3,   0,   0,   0,
      1,   0,   0,   0,  15,  15,
      0,   0,  98,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   3,   0,   0,   0,
      2,   0,   0,   0,   3,   3,
      0,   0,  83,  86,  95,  80,
     79,  83,  73,  84,  73,  79,
     78,   0,  67,  79,  76,  79,
     82,   0,  84,  69,  88,  67,
     79,  79,  82,  68,   0, 171,
     79,  83,  71,  78,  44,   0,
      0,   0,   1,   0,   0,   0,
      8,   0,   0,   0,  32,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   3,   0,
      0,   0,   0,   0,   0,   0,
     15,   0,   0,   0,  83,  86,
     95,  84,  97, 114, 103, 101,
    116,   0, 171, 171
};
inline const unsigned char imgui_vertex_shader[] =
{
     68,  88,  66,  67, 121, 204,
    233,  41, 192,  57,  30, 133,
     32, 100, 189,  62,  70,  74,
     75, 111,   1,   0,   0,   0,
    156,   5,   0,   0,   6,   0,
      0,   0,  56,   0,   0,   0,
    164,   1,   0,   0, 108,   3,
      0,   0, 232,   3,   0,   0,
    184,   4,   0,   0,  40,   5,
      0,   0,  65, 111, 110,  57,
    100,   1,   0,   0, 100,   1,
      0,   0,   0,   2, 254, 255,
     36,   1,   0,   0,  64,   0,
      0,   0,   2,   0,  36,   0,
      0,   0,  60,   0,   0,   0,
     60,   0,   0,   0,  36,   0,
      1,   0,  60,   0,   0,   0,
      0,   0,   2,   0,   1,   0,
      0,   0,   0,   0,   0,   0,
      3,   0,   1,   0,   3,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   1,   2, 254, 255,
     81,   0,   0,   5,   4,   0,
     15, 160,   0,   0,   0,   0,
      0,   0, 128,  63,   0,   0,
      0,   0,   0,   0,   0,   0,
     31,   0,   0,   2,   5,   0,
      0, 128,   0,   0,  15, 144,
     31,   0,   0,   2,   5,   0,
      1, 128,   1,   0,  15, 144,
     31,   0,   0,   2,   5,   0,
      2, 128,   2,   0,  15, 144,
      5,   0,   0,   3,   0,   0,
     15, 128,   0,   0,   0, 144,
      1,   0, 228, 160,   5,   0,
      0,   3,   1,   0,  15, 128,
      0,   0,  85, 144,   2,   0,
    228, 160,   2,   0,   0,   3,
      0,   0,  15, 128,   0,   0,
    228, 128,   1,   0, 228, 128,
      2,   0,   0,   3,   0,   0,
     15, 128,   0,   0, 228, 128,
      4,   0,   0, 160,   1,   0,
      0,   2,   1,   0,   2, 128,
      4,   0,  85, 160,   5,   0,
      0,   3,   1,   0,  15, 128,
      1,   0,  85, 128,   3,   0,
    228, 160,   2,   0,   0,   3,
      0,   0,  15, 128,   0,   0,
    228, 128,   1,   0, 228, 128,
      1,   0,   0,   2,   1,   0,
     15, 128,   1,   0, 228, 144,
      1,   0,   0,   2,   2,   0,
      3, 128,   2,   0, 228, 144,
      1,   0,   0,   2,   0,   0,
     15, 224,   1,   0, 228, 128,
      1,   0,   0,   2,   0,   0,
      3, 128,   0,   0, 228, 128,
      1,   0,   0,   2,   0,   0,
     12, 128,   0,   0, 228, 128,
      1,   0,   0,   2,   1,   0,
      3, 224,   2,   0, 228, 128,
      5,   0,   0,   3,   1,   0,
      3, 128,   0,   0, 255, 128,
      0,   0, 228, 160,   2,   0,
      0,   3,   0,   0,   3, 192,
      0,   0, 228, 128,   1,   0,
    228, 128,   1,   0,   0,   2,
      0,   0,  12, 192,   0,   0,
    228, 128, 255, 255,   0,   0,
     83,  72,  68,  82, 192,   1,
      0,   0,  64,   0,   1,   0,
    112,   0,   0,   0,  89,   0,
      0,   4,  70, 142,  32,   0,
      0,   0,   0,   0,   4,   0,
      0,   0,  95,   0,   0,   3,
     50,  16,  16,   0,   0,   0,
      0,   0,  95,   0,   0,   3,
    242,  16,  16,   0,   1,   0,
      0,   0,  95,   0,   0,   3,
     50,  16,  16,   0,   2,   0,
      0,   0, 103,   0,   0,   4,
    242,  32,  16,   0,   0,   0,
      0,   0,   1,   0,   0,   0,
    101,   0,   0,   3, 242,  32,
     16,   0,   1,   0,   0,   0,
    101,   0,   0,   3,  50,  32,
     16,   0,   2,   0,   0,   0,
    104,   0,   0,   2,   3,   0,
      0,   0,  56,   0,   0,   8,
    242,   0,  16,   0,   0,   0,
      0,   0,   6,  16,  16,   0,
      0,   0,   0,   0,  70, 142,
     32,   0,   0,   0,   0,   0,
      0,   0,   0,   0,  56,   0,
      0,   8, 242,   0,  16,   0,
      1,   0,   0,   0,  86,  21,
     16,   0,   0,   0,   0,   0,
     70, 142,  32,   0,   0,   0,
      0,   0,   1,   0,   0,   0,
      0,   0,   0,   7, 242,   0,
     16,   0,   0,   0,   0,   0,
     70,  14,  16,   0,   0,   0,
      0,   0,  70,  14,  16,   0,
      1,   0,   0,   0,  56,   0,
      0,  11, 242,   0,  16,   0,
      1,   0,   0,   0,  70, 142,
     32,   0,   0,   0,   0,   0,
      2,   0,   0,   0,   2,  64,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   7, 242,   0,
     16,   0,   0,   0,   0,   0,
     70,  14,  16,   0,   0,   0,
      0,   0,  70,  14,  16,   0,
      1,   0,   0,   0,  56,   0,
      0,  11, 242,   0,  16,   0,
      1,   0,   0,   0,  70, 142,
     32,   0,   0,   0,   0,   0,
      3,   0,   0,   0,   2,  64,
      0,   0,   0,   0, 128,  63,
      0,   0, 128,  63,   0,   0,
    128,  63,   0,   0, 128,  63,
      0,   0,   0,   7, 242,   0,
     16,   0,   0,   0,   0,   0,
     70,  14,  16,   0,   0,   0,
      0,   0,  70,  14,  16,   0,
      1,   0,   0,   0,  54,   0,
      0,   5, 242,   0,  16,   0,
      1,   0,   0,   0,  70,  30,
     16,   0,   1,   0,   0,   0,
     54,   0,   0,   5,  50,   0,
     16,   0,   2,   0,   0,   0,
     70,  16,  16,   0,   2,   0,
      0,   0,  54,   0,   0,   5,
    242,  32,  16,   0,   0,   0,
      0,   0,  70,  14,  16,   0,
      0,   0,   0,   0,  54,   0,
      0,   5, 242,  32,  16,   0,
      1,   0,   0,   0,  70,  14,
     16,   0,   1,   0,   0,   0,
     54,   0,   0,   5,  50,  32,
     16,   0,   2,   0,   0,   0,
     70,   0,  16,   0,   2,   0,
      0,   0,  62,   0,   0,   1,
     83,  84,  65,  84, 116,   0,
      0,   0,  13,   0,   0,   0,
      3,   0,   0,   0,   0,   0,
      0,   0,   6,   0,   0,   0,
      7,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      1,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      5,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,  82,  68,
     69,  70, 200,   0,   0,   0,
      1,   0,   0,   0,  76,   0,
      0,   0,   1,   0,   0,   0,
     28,   0,   0,   0,   0,   4,
    254, 255,   4,   1,   0,   0,
    160,   0,   0,   0,  60,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   1,   0,
      0,   0,   1,   0,   0,   0,
    118, 101, 114, 116, 101, 120,
     66, 117, 102, 102, 101, 114,
      0, 171, 171, 171,  60,   0,
      0,   0,   1,   0,   0,   0,
    100,   0,   0,   0,  64,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0, 124,   0,
      0,   0,   0,   0,   0,   0,
     64,   0,   0,   0,   2,   0,
      0,   0, 144,   0,   0,   0,
      0,   0,   0,   0,  80, 114,
    111, 106, 101,  99, 116, 105,
    111, 110,  77,  97, 116, 114,
    105, 120,   0, 171, 171, 171,
      3,   0,   3,   0,   4,   0,
      4,   0,   0,   0,   0,   0,
      0,   0,   0,   0,  77, 105,
     99, 114, 111, 115, 111, 102,
    116,  32,  40,  82,  41,  32,
     72,  76,  83,  76,  32,  83,
    104,  97, 100, 101, 114,  32,
     67, 111, 109, 112, 105, 108,
    101, 114,  32,  49,  48,  46,
     49,   0,  73,  83,  71,  78,
    104,   0,   0,   0,   3,   0,
      0,   0,   8,   0,   0,   0,
     80,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      3,   0,   0,   0,   0,   0,
      0,   0,   3,   3,   0,   0,
     89,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      3,   0,   0,   0,   1,   0,
      0,   0,  15,  15,   0,   0,
     95,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,
      3,   0,   0,   0,   2,   0,
      0,   0,   3,   3,   0,   0,
     80,  79,  83,  73,  84,  73,
     79,  78,   0,  67,  79,  76,
     79,  82,   0,  84,  69,  88,
     67,  79,  79,  82,  68,   0,
     79,  83,  71,  78, 108,   0,
      0,   0,   3,   0,   0,   0,
      8,   0,   0,   0,  80,   0,
      0,   0,   0,   0,   0,   0,
      1,   0,   0,   0,   3,   0,
      0,   0,   0,   0,   0,   0,
     15,   0,   0,   0,  92,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   3,   0,
      0,   0,   1,   0,   0,   0,
     15,   0,   0,   0,  98,   0,
      0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   3,   0,
      0,   0,   2,   0,   0,   0,
      3,  12,   0,   0,  83,  86,
     95,  80,  79,  83,  73,  84,
     73,  79,  78,   0,  67,  79,
     76,  79,  82,   0,  84,  69,
     88,  67,  79,  79,  82,  68,
      0, 171
};
namespace bypass {
    extern bool CanPresent();
};
namespace ImGuiRenderStreamImplDx11 {
    
    namespace G{
        inline ID3D11Device* pd3dDevice;
        inline ID3D11DeviceContext* pd3dDeviceContext;
        inline IDXGISwapChain* pd3dSwapChain;
        inline IDXGIFactory* pFactory;
        inline ID3D11Buffer* pVB;
        inline ID3D11Buffer* pIB;
        inline ID3D11VertexShader* pVertexShader;
        inline ID3D11InputLayout* pInputLayout;
        inline ID3D11Buffer* pVertexConstantBuffer;
        inline ID3D11PixelShader* pPixelShader;
        inline ID3D11SamplerState* pFontSampler;

        inline std::unordered_map<INT64, ID3D11ShaderResourceView*> pTextureViewMap;

        inline ID3D11RasterizerState* pRasterizerState;
        inline ID3D11BlendState* pBlendState;
        inline ID3D11DepthStencilState* pDepthStencilState;
        inline int                         VertexBufferSize;
        inline int                         IndexBufferSize;
    };
    
    
    namespace RS = RenderStream;

    inline bool Init(IDXGISwapChain* swapChain,ID3D11Device* device, ID3D11DeviceContext* device_context)
    {
        swapChain->AddRef();
        G::pd3dSwapChain = swapChain;


        IDXGIDevice* pDXGIDevice = NULL;
        IDXGIAdapter* pDXGIAdapter = NULL;
        IDXGIFactory* pFactory = NULL;

        GUID IID_IDXGIDevice = { 0x54ec77fa, 0x1377, 0x44e6, 0x8c, 0x32, 0x88, 0xfd, 0x5f, 0x44, 0xc8, 0x4c };
        GUID IID_IDXGIAdapter = { 0x2411e7e1, 0x12ac, 0x4ccf, 0xbd, 0x14, 0x97, 0x98, 0xe8, 0x53, 0x4d, 0xc0 };
        GUID IID_IDXGIFactory = { 0x7b7166ec, 0x21c7, 0x44ae, 0xb2, 0x1a, 0xc9, 0xae, 0x32, 0x1a, 0xe3, 0x69 };

        if (device->QueryInterface(IID_IDXGIDevice, (void**)(&pDXGIDevice)) == S_OK) {
            if (pDXGIDevice->GetParent(IID_IDXGIAdapter, (void**)(&pDXGIAdapter)) == S_OK) {
                if (pDXGIAdapter->GetParent(IID_IDXGIFactory, (void**)(&pFactory)) == S_OK)
                {
                    G::pd3dDevice = device;
                    G::pd3dDeviceContext = device_context;
                    G::pFactory = pFactory;
                }
            }
        }
        if (pDXGIDevice) pDXGIDevice->Release();
        if (pDXGIAdapter) pDXGIAdapter->Release();

        G::pd3dDevice->AddRef();
        G::pd3dDeviceContext->AddRef();




        {
            auto hr = G::pd3dDevice->CreateVertexShader(imgui_vertex_shader, sizeof(imgui_vertex_shader), NULL, &G::pVertexShader);
            if (hr != S_OK)
            {
                return false;
            }

            std::string POSITION = xorstr_("POSITION");
            std::string TEXCOORD = xorstr_("TEXCOORD");
            std::string COLOR = xorstr_("COLOR");
            // Create the input layout
            D3D11_INPUT_ELEMENT_DESC local_layout[] =
            {
                { POSITION.c_str(), 0, DXGI_FORMAT_R32G32_FLOAT,   0, (UINT)0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
                { TEXCOORD.c_str(), 0, DXGI_FORMAT_R32G32_FLOAT,   0, (UINT)8,  D3D11_INPUT_PER_VERTEX_DATA, 0 },
                { COLOR.c_str(),    0, DXGI_FORMAT_R8G8B8A8_UNORM, 0, (UINT)16, D3D11_INPUT_PER_VERTEX_DATA, 0 },
            };
          
            hr = G::pd3dDevice->CreateInputLayout(local_layout, 3, imgui_vertex_shader, sizeof(imgui_vertex_shader), &G::pInputLayout);
            if (hr != S_OK)
            {
                return false;
            }

            // Create the constant buffer
            {
                D3D11_BUFFER_DESC desc;
                desc.ByteWidth = 64;
                desc.Usage = D3D11_USAGE_DYNAMIC;
                desc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
                desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
                desc.MiscFlags = 0;
                hr = G::pd3dDevice->CreateBuffer(&desc, NULL, &G::pVertexConstantBuffer);
            }
        }
        // DebugBreak();
         // Create the pixel shader
        {
            auto hr = G::pd3dDevice->CreatePixelShader(imgui_pixel_shader, sizeof(imgui_pixel_shader), NULL, &G::pPixelShader);
            if (hr != S_OK)
            {
                return false;
            }
        }

        // Create the blending setup
        {
            D3D11_BLEND_DESC desc;
            ZeroMemory(&desc, sizeof(desc));
            desc.AlphaToCoverageEnable = false;
            desc.RenderTarget[0].BlendEnable = true;
            desc.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
            desc.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
            desc.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
            desc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
            desc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_INV_SRC_ALPHA;
            desc.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
            desc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
            G::pd3dDevice->CreateBlendState(&desc, &G::pBlendState);
        }

        // Create the rasterizer state
        {
            D3D11_RASTERIZER_DESC desc;
            ZeroMemory(&desc, sizeof(desc));
            desc.FillMode = D3D11_FILL_SOLID;
            desc.CullMode = D3D11_CULL_NONE;
            desc.ScissorEnable = true;
            desc.DepthClipEnable = true;
            G::pd3dDevice->CreateRasterizerState(&desc, &G::pRasterizerState);
        }

        // Create depth-stencil State
        {
            D3D11_DEPTH_STENCIL_DESC desc;
            ZeroMemory(&desc, sizeof(desc));
            desc.DepthEnable = false;
            desc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ALL;
            desc.DepthFunc = D3D11_COMPARISON_ALWAYS;
            desc.StencilEnable = false;
            desc.FrontFace.StencilFailOp = desc.FrontFace.StencilDepthFailOp = desc.FrontFace.StencilPassOp = D3D11_STENCIL_OP_KEEP;
            desc.FrontFace.StencilFunc = D3D11_COMPARISON_ALWAYS;
            desc.BackFace = desc.FrontFace;
            G::pd3dDevice->CreateDepthStencilState(&desc, &G::pDepthStencilState);
        }





        return true;
    }
    struct BACKUP_DX11_STATE
    {
        UINT                        ScissorRectsCount, ViewportsCount;
        D3D11_RECT                  ScissorRects[D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE];
        D3D11_VIEWPORT              Viewports[D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE];
        ID3D11RasterizerState* RS;
        ID3D11BlendState* BlendState;
        FLOAT                       BlendFactor[4];
        UINT                        SampleMask;
        UINT                        StencilRef;
        ID3D11DepthStencilState* DepthStencilState;
        ID3D11ShaderResourceView* PSShaderResource;
        ID3D11SamplerState* PSSampler;
        ID3D11PixelShader* PS;
        ID3D11VertexShader* VS;
        ID3D11GeometryShader* GS;
        UINT                        PSInstancesCount, VSInstancesCount, GSInstancesCount;
        ID3D11ClassInstance* PSInstances[256], * VSInstances[256], * GSInstances[256];
        D3D11_PRIMITIVE_TOPOLOGY    PrimitiveTopology;
        ID3D11Buffer* IndexBuffer, * VertexBuffer, * VSConstantBuffer;
        UINT                        IndexBufferOffset, VertexBufferStride, VertexBufferOffset;
        DXGI_FORMAT                 IndexBufferFormat;
        ID3D11InputLayout* InputLayout;
    };

    inline void RenderData(std::vector<int8_t>& data) {
        
        if (!(G::pFontSampler) || (G::pTextureViewMap.size() <= 0)) {
            {
                int8_t* pBuf = data.data();
                while (((RS::dataheader*)pBuf)->type != RS::datatype::Unknown && pBuf < data.data()+ data.size()) {
                    if (((RS::dataheader*)pBuf)->type == RS::datatype::FunSetShaderResources) {
                        
                       INT64 combination_handle = ((RS::DataSetShaderResources*)(pBuf + sizeof(RS::dataheader)))->TexID;

                       {
                           auto* CommunicaBuffer = RS::RSFactory::GetInstance().OpenCommunicaBuffer(combination_handle);

                           //printf("�������� %p", CommunicaBuffer->GetSharedHandle());

                           std::vector<int8_t> fontTex;
                           CommunicaBuffer->Download(fontTex);

                           D3D11_TEXTURE2D_DESC desc;
                           ZeroMemory(&desc, sizeof(desc));
                           desc.Width = ((int*)fontTex.data())[0];
                           desc.Height = ((int*)fontTex.data())[1];
                           desc.MipLevels = 1;
                           desc.ArraySize = 1;
                           desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
                           desc.SampleDesc.Count = 1;
                           desc.Usage = D3D11_USAGE_DEFAULT;
                           desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;
                           desc.CPUAccessFlags = 0;
                           auto* pixels = fontTex.data() + (sizeof(int) * 2);
                           ID3D11Texture2D* pTexture = NULL;
                           D3D11_SUBRESOURCE_DATA subResource;
                           subResource.pSysMem = pixels;
                           subResource.SysMemPitch = desc.Width * 4;
                           subResource.SysMemSlicePitch = 0;
                           G::pd3dDevice->CreateTexture2D(&desc, &subResource, &pTexture);


                           // Create texture view
                           D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc;
                           ZeroMemory(&srvDesc, sizeof(srvDesc));
                           srvDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
                           srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
                           srvDesc.Texture2D.MipLevels = desc.MipLevels;
                           srvDesc.Texture2D.MostDetailedMip = 0;


                           ID3D11ShaderResourceView* pFontTextureView = 0;
                           G::pd3dDevice->CreateShaderResourceView(pTexture, &srvDesc, &pFontTextureView);


                           G::pTextureViewMap.insert({ combination_handle, pFontTextureView });

                           pTexture->Release();
                       }

                       {
                           D3D11_SAMPLER_DESC desc;
                           ZeroMemory(&desc, sizeof(desc));
                           desc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
                           desc.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
                           desc.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
                           desc.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
                           desc.MipLODBias = 0.f;
                           desc.ComparisonFunc = D3D11_COMPARISON_ALWAYS;
                           desc.MinLOD = 0.f;
                           desc.MaxLOD = 0.f;
                           G::pd3dDevice->CreateSamplerState(&desc, &G::pFontSampler);
                       }
                       

                       break;
                    }
                    //printf("���� %d\n", (((RS::dataheader*)pBuf)->size));
                    pBuf += (((RS::dataheader*)pBuf)->size) + sizeof(RS::dataheader);
                }

            }
            
        
        }

        BACKUP_DX11_STATE old = {};
        old.ScissorRectsCount = old.ViewportsCount = D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE;
        G::pd3dDeviceContext->RSGetScissorRects(&old.ScissorRectsCount, old.ScissorRects);
        G::pd3dDeviceContext->RSGetViewports(&old.ViewportsCount, old.Viewports);
        G::pd3dDeviceContext->RSGetState(&old.RS);
        G::pd3dDeviceContext->OMGetBlendState(&old.BlendState, old.BlendFactor, &old.SampleMask);
        G::pd3dDeviceContext->OMGetDepthStencilState(&old.DepthStencilState, &old.StencilRef);
        G::pd3dDeviceContext->PSGetShaderResources(0, 1, &old.PSShaderResource);
        G::pd3dDeviceContext->PSGetSamplers(0, 1, &old.PSSampler);
        old.PSInstancesCount = old.VSInstancesCount = old.GSInstancesCount = 256;
        G::pd3dDeviceContext->PSGetShader(&old.PS, old.PSInstances, &old.PSInstancesCount);
        G::pd3dDeviceContext->VSGetShader(&old.VS, old.VSInstances, &old.VSInstancesCount);
        G::pd3dDeviceContext->VSGetConstantBuffers(0, 1, &old.VSConstantBuffer);
        G::pd3dDeviceContext->GSGetShader(&old.GS, old.GSInstances, &old.GSInstancesCount);

        G::pd3dDeviceContext->IAGetPrimitiveTopology(&old.PrimitiveTopology);
        G::pd3dDeviceContext->IAGetIndexBuffer(&old.IndexBuffer, &old.IndexBufferFormat, &old.IndexBufferOffset);
        G::pd3dDeviceContext->IAGetVertexBuffers(0, 1, &old.VertexBuffer, &old.VertexBufferStride, &old.VertexBufferOffset);
        G::pd3dDeviceContext->IAGetInputLayout(&old.InputLayout);


        static D3D11_VIEWPORT vp{};
        

        {
            int8_t* pBuf = data.data();
        
            while (((RS::dataheader*)pBuf)->type != RS::datatype::Unknown && pBuf < data.data() + data.size()) {


                if (((RS::dataheader*)pBuf)->type == RS::datatype::DrawVert) {
                    char* VertPtr = (char*)(pBuf + sizeof(RS::dataheader));
                    int VertSize = ((RS::dataheader*)pBuf)->size;

                    if (!G::pVB || G::VertexBufferSize < (int)( VertSize/20 ))
                    {
                        if (G::pVB) { G::pVB->Release(); G::pVB = NULL; }
                        G::VertexBufferSize = (int)(VertSize / 20) + 5000;
                        D3D11_BUFFER_DESC desc;
                        memset(&desc, 0, sizeof(D3D11_BUFFER_DESC));
                        desc.Usage = D3D11_USAGE_DYNAMIC;
                        desc.ByteWidth = G::VertexBufferSize * 20;
                        desc.BindFlags = D3D11_BIND_VERTEX_BUFFER;
                        desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
                        desc.MiscFlags = 0;
                        if (G::pd3dDevice->CreateBuffer(&desc, NULL, &G::pVB) < 0)
                            return;
                    }

                    D3D11_MAPPED_SUBRESOURCE vtx_resource{};
                    if (G::pd3dDeviceContext->Map(G::pVB, 0, D3D11_MAP_WRITE_DISCARD, 0, &vtx_resource) == S_OK) {
                        memcpy(vtx_resource.pData, VertPtr, VertSize);
                        G::pd3dDeviceContext->Unmap(G::pVB, 0);
                    }
                }

                if (((RS::dataheader*)pBuf)->type == RS::datatype::DrawIdx) {
                    char* IdxPtr = (char*)(pBuf + sizeof(RS::dataheader));
                    int IdxSize = ((RS::dataheader*)pBuf)->size;

                    if (!G::pIB || G::IndexBufferSize < (int)(IdxSize/2))
                    {
                        if (G::pIB) { G::pIB->Release(); G::pIB = NULL; }
                        G::IndexBufferSize = (int)(IdxSize / 2) + 10000;
                        D3D11_BUFFER_DESC desc;
                        memset(&desc, 0, sizeof(D3D11_BUFFER_DESC));
                        desc.Usage = D3D11_USAGE_DYNAMIC;
                        desc.ByteWidth = G::IndexBufferSize * 2;
                        desc.BindFlags = D3D11_BIND_INDEX_BUFFER;
                        desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
                        if (G::pd3dDevice->CreateBuffer(&desc, NULL, &G::pIB) < 0)
                            return;
                    }

                    D3D11_MAPPED_SUBRESOURCE idx_resource{};
                    if (G::pd3dDeviceContext->Map(G::pIB, 0, D3D11_MAP_WRITE_DISCARD, 0, &idx_resource) == S_OK) {
                        memcpy(idx_resource.pData, IdxPtr, IdxSize);
                        G::pd3dDeviceContext->Unmap(G::pIB, 0);
                    }


                }

                if (((RS::dataheader*)pBuf)->type == RS::datatype::VertexConstantBuffer) {
                    {
                        RS::DataVertexConstantBuffer* DataVertexConstantBuffer = (RS::DataVertexConstantBuffer*)(pBuf + sizeof(RS::dataheader));
                        vp = DataVertexConstantBuffer->vp.dx11;

                        struct VERTEX_CONSTANT_BUFFER
                        {
                            float   mvp[4][4];
                        };

                        D3D11_MAPPED_SUBRESOURCE mapped_resource;
                        if (G::pd3dDeviceContext->Map(G::pVertexConstantBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mapped_resource) != S_OK)
                            return;
                        VERTEX_CONSTANT_BUFFER* constant_buffer = (VERTEX_CONSTANT_BUFFER*)mapped_resource.pData;
                        

                        ID3D11Texture2D* back_buffer = 0;
                        GUID IID_ID3D11Texture2D = { 0x6f15aaf2,0xd208,0x4e89,0x9a,0xb4,0x48,0x95,0x35,0xd3,0x4f,0x9c };
                        G::pd3dSwapChain->GetBuffer(0, IID_ID3D11Texture2D, (void**)& back_buffer);
                        D3D11_TEXTURE2D_DESC back_buffer_desc{};
                        back_buffer->GetDesc(&back_buffer_desc);
                        float L = 0.0F;
                        float R = 0.0F + back_buffer_desc.Width;
                        float T = 0.0F;
                        float B = 0.0F + back_buffer_desc.Height;
                        float mvp[4][4] =
                        {
                            { 2.0f / (R - L),   0.0f,           0.0f,       0.0f },
                            { 0.0f,         2.0f / (T - B),     0.0f,       0.0f },
                            { 0.0f,         0.0f,           0.5f,       0.0f },
                            { (R + L) / (L - R),  (T + B) / (B - T),    0.5f,       1.0f },
                        };
                        memcpy(&constant_buffer->mvp, mvp, sizeof(mvp));
                        G::pd3dDeviceContext->Unmap(G::pVertexConstantBuffer, 0);
                        back_buffer->Release();
                    }

                }

                {
                    G::pd3dDeviceContext->RSSetViewports(1, &vp);

                    unsigned int stride = 20;
                    unsigned int offset = 0;
                    G::pd3dDeviceContext->IASetInputLayout(G::pInputLayout);
                    G::pd3dDeviceContext->IASetVertexBuffers(0, 1, &G::pVB, &stride, &offset);
                    G::pd3dDeviceContext->IASetIndexBuffer(G::pIB, 2 == 2 ? DXGI_FORMAT_R16_UINT : DXGI_FORMAT_R32_UINT, 0);
                    G::pd3dDeviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
                    G::pd3dDeviceContext->VSSetShader(G::pVertexShader, NULL, 0);
                    G::pd3dDeviceContext->VSSetConstantBuffers(0, 1, &G::pVertexConstantBuffer);
                    G::pd3dDeviceContext->PSSetShader(G::pPixelShader, NULL, 0);
                    G::pd3dDeviceContext->PSSetSamplers(0, 1, &G::pFontSampler);
                    G::pd3dDeviceContext->GSSetShader(NULL, NULL, 0);
                    G::pd3dDeviceContext->HSSetShader(NULL, NULL, 0); // In theory we should backup and restore this as well.. very infrequently used..
                    G::pd3dDeviceContext->DSSetShader(NULL, NULL, 0); // In theory we should backup and restore this as well.. very infrequently used..
                    G::pd3dDeviceContext->CSSetShader(NULL, NULL, 0); // In theory we should backup and restore this as well.. very infrequently used..

                    // Setup blend state
                    const float blend_factor[4] = { 0.f, 0.f, 0.f, 0.f };
                    G::pd3dDeviceContext->OMSetBlendState(G::pBlendState, blend_factor, 0xffffffff);
                    G::pd3dDeviceContext->OMSetDepthStencilState(G::pDepthStencilState, 0);
                    G::pd3dDeviceContext->RSSetState(G::pRasterizerState);
                }


                if (((RS::dataheader*)pBuf)->type == RS::datatype::FunSetScissorRects) {
                    RS::DataSetScissorRects* SetScissorRectsPtr = (RS::DataSetScissorRects*)(pBuf + sizeof(RS::dataheader));
                    G::pd3dDeviceContext->RSSetScissorRects(SetScissorRectsPtr->NumRects,&(SetScissorRectsPtr->rect.dx11));
                }
                if (((RS::dataheader*)pBuf)->type == RS::datatype::FunSetShaderResources) {
                    RS::DataSetShaderResources* SetShaderResourcesPtr = (RS::DataSetShaderResources*)(pBuf + sizeof(RS::dataheader));
                    auto iter = G::pTextureViewMap.find(SetShaderResourcesPtr->TexID);
                    if (iter != G::pTextureViewMap.end()) {
                        auto* pShaderResourceViews = iter->second;
                        G::pd3dDeviceContext->PSSetShaderResources(SetShaderResourcesPtr->StartSlot, SetShaderResourcesPtr->NumViews, &pShaderResourceViews);
                    }
                    else {

                        {
                            auto* CommunicaBuffer = RS::RSFactory::GetInstance().OpenCommunicaBuffer(SetShaderResourcesPtr->TexID);

                            std::vector<int8_t> fontTex;
                            CommunicaBuffer->Download(fontTex);

                            D3D11_TEXTURE2D_DESC desc;
                            ZeroMemory(&desc, sizeof(desc));
                            desc.Width = ((int*)fontTex.data())[0];
                            desc.Height = ((int*)fontTex.data())[1];
                            desc.MipLevels = 1;
                            desc.ArraySize = 1;
                            desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
                            desc.SampleDesc.Count = 1;
                            desc.Usage = D3D11_USAGE_DEFAULT;
                            desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;
                            desc.CPUAccessFlags = 0;
                            auto* pixels = fontTex.data() + (sizeof(int) * 2);
                            ID3D11Texture2D* pTexture = NULL;
                            D3D11_SUBRESOURCE_DATA subResource;
                            subResource.pSysMem = pixels;
                            subResource.SysMemPitch = desc.Width * 4;
                            subResource.SysMemSlicePitch = 0;
                            G::pd3dDevice->CreateTexture2D(&desc, &subResource, &pTexture);


                            // Create texture view
                            D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc;
                            ZeroMemory(&srvDesc, sizeof(srvDesc));
                            srvDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
                            srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
                            srvDesc.Texture2D.MipLevels = desc.MipLevels;
                            srvDesc.Texture2D.MostDetailedMip = 0;


                            ID3D11ShaderResourceView* pFontTextureView = 0;
                            G::pd3dDevice->CreateShaderResourceView(pTexture, &srvDesc, &pFontTextureView);


                            G::pTextureViewMap.insert({ SetShaderResourcesPtr->TexID, pFontTextureView });
                            G::pd3dDeviceContext->PSSetShaderResources(SetShaderResourcesPtr->StartSlot, SetShaderResourcesPtr->NumViews, &pFontTextureView);
                            pTexture->Release();
                        }
                    
                    }
                }
                if (((RS::dataheader*)pBuf)->type == RS::datatype::FunDataDrawIndexed) {
                    RS::DataDrawIndexed* DrawIndexedPtr = (RS::DataDrawIndexed*)(pBuf + sizeof(RS::dataheader));
                    
                    if (bypass::CanPresent())
                        G::pd3dDeviceContext->DrawIndexed(DrawIndexedPtr->IndexCount, DrawIndexedPtr->StartIndexLocation, DrawIndexedPtr->BaseVertexLocation);
                    
                }


                pBuf += (((RS::dataheader*)pBuf)->size) + sizeof(RS::dataheader);
            }
        }
       

        G::pd3dDeviceContext->RSSetScissorRects(old.ScissorRectsCount, old.ScissorRects);
        G::pd3dDeviceContext->RSSetViewports(old.ViewportsCount, old.Viewports);
        G::pd3dDeviceContext->RSSetState(old.RS); if (old.RS) old.RS->Release();
        G::pd3dDeviceContext->OMSetBlendState(old.BlendState, old.BlendFactor, old.SampleMask); if (old.BlendState) old.BlendState->Release();
        G::pd3dDeviceContext->OMSetDepthStencilState(old.DepthStencilState, old.StencilRef); if (old.DepthStencilState) old.DepthStencilState->Release();
        G::pd3dDeviceContext->PSSetShaderResources(0, 1, &old.PSShaderResource); if (old.PSShaderResource) old.PSShaderResource->Release();
        G::pd3dDeviceContext->PSSetSamplers(0, 1, &old.PSSampler); if (old.PSSampler) old.PSSampler->Release();
        G::pd3dDeviceContext->PSSetShader(old.PS, old.PSInstances, old.PSInstancesCount); if (old.PS) old.PS->Release();
        for (UINT i = 0; i < old.PSInstancesCount; i++) if (old.PSInstances[i]) old.PSInstances[i]->Release();
        G::pd3dDeviceContext->VSSetShader(old.VS, old.VSInstances, old.VSInstancesCount); if (old.VS) old.VS->Release();
        G::pd3dDeviceContext->VSSetConstantBuffers(0, 1, &old.VSConstantBuffer); if (old.VSConstantBuffer) old.VSConstantBuffer->Release();
        G::pd3dDeviceContext->GSSetShader(old.GS, old.GSInstances, old.GSInstancesCount); if (old.GS) old.GS->Release();
        for (UINT i = 0; i < old.VSInstancesCount; i++) if (old.VSInstances[i]) old.VSInstances[i]->Release();
        G::pd3dDeviceContext->IASetPrimitiveTopology(old.PrimitiveTopology);
        G::pd3dDeviceContext->IASetIndexBuffer(old.IndexBuffer, old.IndexBufferFormat, old.IndexBufferOffset); if (old.IndexBuffer) old.IndexBuffer->Release();
        G::pd3dDeviceContext->IASetVertexBuffers(0, 1, &old.VertexBuffer, &old.VertexBufferStride, &old.VertexBufferOffset); if (old.VertexBuffer) old.VertexBuffer->Release();
        G::pd3dDeviceContext->IASetInputLayout(old.InputLayout); if (old.InputLayout) old.InputLayout->Release();
       
    };
};
namespace ImGuiRenderStreamImplDx10 {
    namespace G {
        inline ID3D10Device1* pd3dDevice;
        inline IDXGISwapChain* pd3dSwapChain;
        inline IDXGIFactory* pFactory;
        inline ID3D10Buffer* pVB;
        inline ID3D10Buffer* pIB;
        inline ID3D10VertexShader* pVertexShader;
        inline ID3D10InputLayout* pInputLayout;
        inline ID3D10Buffer* pVertexConstantBuffer;
        inline ID3D10PixelShader* pPixelShader;
        inline ID3D10SamplerState* pFontSampler;
        inline std::unordered_map<INT64, ID3D10ShaderResourceView*> pTextureViewMap;
        inline ID3D10RasterizerState* pRasterizerState;
        inline ID3D10BlendState* pBlendState;
        inline ID3D10DepthStencilState* pDepthStencilState;
        inline int                         VertexBufferSize;
        inline int                         IndexBufferSize;
    }
    namespace RS = RenderStream;

    inline bool Init(IDXGISwapChain* swapChain, ID3D10Device1* device)
    {
        swapChain->AddRef();
        G::pd3dSwapChain = swapChain;


        IDXGIDevice* pDXGIDevice = NULL;
        IDXGIAdapter* pDXGIAdapter = NULL;
        IDXGIFactory* pFactory = NULL;

        GUID IID_IDXGIDevice = { 0x54ec77fa, 0x1377, 0x44e6, 0x8c, 0x32, 0x88, 0xfd, 0x5f, 0x44, 0xc8, 0x4c };
        GUID IID_IDXGIAdapter = { 0x2411e7e1, 0x12ac, 0x4ccf, 0xbd, 0x14, 0x97, 0x98, 0xe8, 0x53, 0x4d, 0xc0 };
        GUID IID_IDXGIFactory = { 0x7b7166ec, 0x21c7, 0x44ae, 0xb2, 0x1a, 0xc9, 0xae, 0x32, 0x1a, 0xe3, 0x69 };

        if (device->QueryInterface(IID_IDXGIDevice, (void**)(&pDXGIDevice)) == S_OK) {
            if (pDXGIDevice->GetParent(IID_IDXGIAdapter, (void**)(&pDXGIAdapter)) == S_OK) {
                if (pDXGIAdapter->GetParent(IID_IDXGIFactory, (void**)(&pFactory)) == S_OK)
                {
                    G::pd3dDevice = device;
                    G::pFactory = pFactory;
                }
            }
        }
        if (pDXGIDevice) pDXGIDevice->Release();
        if (pDXGIAdapter) pDXGIAdapter->Release();

        G::pd3dDevice->AddRef();




        {
            auto hr = G::pd3dDevice->CreateVertexShader(imgui_vertex_shader, sizeof(imgui_vertex_shader), &G::pVertexShader);
            if (hr != S_OK){
                return false;
            }

            std::string POSITION = xorstr_("POSITION");
            std::string TEXCOORD = xorstr_("TEXCOORD");
            std::string COLOR = xorstr_("COLOR");
            // Create the input layout
            D3D10_INPUT_ELEMENT_DESC local_layout[] =
            {
                { POSITION.c_str(), 0, DXGI_FORMAT_R32G32_FLOAT,   0, (UINT)0,  D3D10_INPUT_PER_VERTEX_DATA, 0 },
                { TEXCOORD.c_str(), 0, DXGI_FORMAT_R32G32_FLOAT,   0, (UINT)8,  D3D10_INPUT_PER_VERTEX_DATA, 0 },
                { COLOR.c_str(),    0, DXGI_FORMAT_R8G8B8A8_UNORM, 0, (UINT)16, D3D10_INPUT_PER_VERTEX_DATA, 0 },
            };

            hr = G::pd3dDevice->CreateInputLayout(local_layout, 3, imgui_vertex_shader, sizeof(imgui_vertex_shader), &G::pInputLayout);
            if (hr != S_OK)
            {
                return false;
            }

            // Create the constant buffer
            {
                D3D10_BUFFER_DESC desc;
                desc.ByteWidth = 64;
                desc.Usage = D3D10_USAGE_DYNAMIC;
                desc.BindFlags = D3D10_BIND_CONSTANT_BUFFER;
                desc.CPUAccessFlags = D3D10_CPU_ACCESS_WRITE;
                desc.MiscFlags = 0;
                hr = G::pd3dDevice->CreateBuffer(&desc, NULL, &G::pVertexConstantBuffer);
            }
        }
        // DebugBreak();
         // Create the pixel shader
        {
            auto hr = G::pd3dDevice->CreatePixelShader(imgui_pixel_shader, sizeof(imgui_pixel_shader), &G::pPixelShader);
            if (hr != S_OK){
                return false;
            }
        }

        // Create the blending setup
        {
            D3D10_BLEND_DESC desc;
            ZeroMemory(&desc, sizeof(desc));
            desc.AlphaToCoverageEnable = false;
            desc.BlendEnable[0] = true;
            desc.SrcBlend = D3D10_BLEND_SRC_ALPHA;
            desc.DestBlend = D3D10_BLEND_INV_SRC_ALPHA;
            desc.BlendOp = D3D10_BLEND_OP_ADD;
            desc.SrcBlendAlpha = D3D10_BLEND_ONE;
            desc.DestBlendAlpha = D3D10_BLEND_INV_SRC_ALPHA;
            desc.BlendOpAlpha = D3D10_BLEND_OP_ADD;
            desc.RenderTargetWriteMask[0] = D3D10_COLOR_WRITE_ENABLE_ALL;


            if (G::pd3dDevice->GetFeatureLevel() == D3D10_FEATURE_LEVEL_9_3) {
                desc.BlendEnable[1] = true;
                desc.BlendEnable[2] = true;
                desc.BlendEnable[3] = true;
                desc.BlendEnable[4] = true;
                desc.BlendEnable[5] = true;
                desc.BlendEnable[6] = true;
                desc.BlendEnable[7] = true;
            }

            G::pd3dDevice->CreateBlendState(&desc, &G::pBlendState);
        }

        // Create the rasterizer state
        {
            D3D10_RASTERIZER_DESC desc;
            ZeroMemory(&desc, sizeof(desc));
            desc.FillMode = D3D10_FILL_SOLID;
            desc.CullMode = D3D10_CULL_NONE;
            desc.ScissorEnable = true;
            desc.DepthClipEnable = true;
            G::pd3dDevice->CreateRasterizerState(&desc, &G::pRasterizerState);
        }

        // Create depth-stencil State
        {
            D3D10_DEPTH_STENCIL_DESC desc;
            ZeroMemory(&desc, sizeof(desc));
            desc.DepthEnable = false;
            desc.DepthWriteMask = D3D10_DEPTH_WRITE_MASK_ALL;
            desc.DepthFunc = D3D10_COMPARISON_ALWAYS;
            desc.StencilEnable = false;
            desc.FrontFace.StencilFailOp = desc.FrontFace.StencilDepthFailOp = desc.FrontFace.StencilPassOp = D3D10_STENCIL_OP_KEEP;
            desc.FrontFace.StencilFunc = D3D10_COMPARISON_ALWAYS;
            desc.BackFace = desc.FrontFace;
            G::pd3dDevice->CreateDepthStencilState(&desc, &G::pDepthStencilState);
        }


        return true;
    }
    struct BACKUP_DX10_STATE
    {
        UINT                        ScissorRectsCount, ViewportsCount;
        D3D10_RECT                  ScissorRects[D3D10_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE];
        D3D10_VIEWPORT              Viewports[D3D10_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE];
        ID3D10RasterizerState* RS;
        ID3D10BlendState* BlendState;
        FLOAT                       BlendFactor[4];
        UINT                        SampleMask;
        UINT                        StencilRef;
        ID3D10DepthStencilState* DepthStencilState;
        ID3D10ShaderResourceView* PSShaderResource;
        ID3D10SamplerState* PSSampler;
        ID3D10PixelShader* PS;
        ID3D10VertexShader* VS;
        ID3D10GeometryShader* GS;
        D3D10_PRIMITIVE_TOPOLOGY    PrimitiveTopology;
        ID3D10Buffer* IndexBuffer, * VertexBuffer, * VSConstantBuffer;
        UINT                        IndexBufferOffset, VertexBufferStride, VertexBufferOffset;
        DXGI_FORMAT                 IndexBufferFormat;
        ID3D10InputLayout* InputLayout;
    };
    inline void RenderData(std::vector<int8_t>& data) {
       
        if (!(G::pFontSampler) || (G::pTextureViewMap.size() <= 0)) {
            {
                int8_t* pBuf = data.data();
                while (((RS::dataheader*)pBuf)->type != RS::datatype::Unknown && pBuf < data.data() + data.size()) {
                    if (((RS::dataheader*)pBuf)->type == RS::datatype::FunSetShaderResources) {
                        INT64 combination_handle = ((RS::DataSetShaderResources*)(pBuf + sizeof(RS::dataheader)))->TexID;
                        {
                            auto* CommunicaBuffer = RS::RSFactory::GetInstance().OpenCommunicaBuffer(combination_handle);

                            std::vector<int8_t> fontTex;
                            CommunicaBuffer->Download(fontTex);


                            D3D10_TEXTURE2D_DESC desc;
                            ZeroMemory(&desc, sizeof(desc));
                            desc.Width  = ((int*)fontTex.data())[0];
                            desc.Height = ((int*)fontTex.data())[1];
                            desc.MipLevels = 1;
                            desc.ArraySize = 1;
                            desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
                            desc.SampleDesc.Count = 1;
                            desc.Usage = D3D10_USAGE_DEFAULT;
                            desc.BindFlags = D3D10_BIND_SHADER_RESOURCE;
                            desc.CPUAccessFlags = 0;
                            auto* pixels = fontTex.data() + (sizeof(int) * 2);
                            ID3D10Texture2D* pTexture = NULL;
                            D3D10_SUBRESOURCE_DATA subResource;
                            subResource.pSysMem = pixels;
                            subResource.SysMemPitch = desc.Width * 4;
                            subResource.SysMemSlicePitch = 0;
                            G::pd3dDevice->CreateTexture2D(&desc, &subResource, &pTexture);
                            

                            // Create texture view
                            D3D10_SHADER_RESOURCE_VIEW_DESC srv_desc;
                            ZeroMemory(&srv_desc, sizeof(srv_desc));
                            srv_desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
                            srv_desc.ViewDimension = D3D10_SRV_DIMENSION_TEXTURE2D;
                            srv_desc.Texture2D.MipLevels = desc.MipLevels;
                            srv_desc.Texture2D.MostDetailedMip = 0;
                            ID3D10ShaderResourceView* pFontTextureView = 0;
                            G::pd3dDevice->CreateShaderResourceView(pTexture, &srv_desc, &pFontTextureView);
                            pTexture->Release();

                            G::pTextureViewMap.insert({ combination_handle, pFontTextureView });

                        }

                        {
                            D3D10_SAMPLER_DESC desc;
                            ZeroMemory(&desc, sizeof(desc));
                            desc.Filter = D3D10_FILTER_MIN_MAG_MIP_LINEAR;
                            desc.AddressU = D3D10_TEXTURE_ADDRESS_WRAP;
                            desc.AddressV = D3D10_TEXTURE_ADDRESS_WRAP;
                            desc.AddressW = D3D10_TEXTURE_ADDRESS_WRAP;
                            desc.MipLODBias = 0.f;
                            desc.ComparisonFunc = D3D10_COMPARISON_ALWAYS;
                            desc.MinLOD = 0.f;
                            desc.MaxLOD = 0.f;

                            if (G::pd3dDevice->GetFeatureLevel() == D3D10_FEATURE_LEVEL_9_3) {
                                desc.MaxLOD = FLT_MAX;
                            }
                            G::pd3dDevice->CreateSamplerState(&desc, &G::pFontSampler);
                        }


                        break;
                    }

                    pBuf += (((RS::dataheader*)pBuf)->size) + sizeof(RS::dataheader);
                }

            }


        }

        BACKUP_DX10_STATE old = {};
        old.ScissorRectsCount = old.ViewportsCount = D3D10_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE;
        G::pd3dDevice->RSGetScissorRects(&old.ScissorRectsCount, old.ScissorRects);
        G::pd3dDevice->RSGetViewports(&old.ViewportsCount, old.Viewports);
        G::pd3dDevice->RSGetState(&old.RS);
        G::pd3dDevice->OMGetBlendState(&old.BlendState, old.BlendFactor, &old.SampleMask);
        G::pd3dDevice->OMGetDepthStencilState(&old.DepthStencilState, &old.StencilRef);
        G::pd3dDevice->PSGetShaderResources(0, 1, &old.PSShaderResource);
        G::pd3dDevice->PSGetSamplers(0, 1, &old.PSSampler);
        G::pd3dDevice->PSGetShader(&old.PS);
        G::pd3dDevice->VSGetShader(&old.VS);
        G::pd3dDevice->VSGetConstantBuffers(0, 1, &old.VSConstantBuffer);
        G::pd3dDevice->GSGetShader(&old.GS);
        G::pd3dDevice->IAGetPrimitiveTopology(&old.PrimitiveTopology);
        G::pd3dDevice->IAGetIndexBuffer(&old.IndexBuffer, &old.IndexBufferFormat, &old.IndexBufferOffset);
        G::pd3dDevice->IAGetVertexBuffers(0, 1, &old.VertexBuffer, &old.VertexBufferStride, &old.VertexBufferOffset);
        G::pd3dDevice->IAGetInputLayout(&old.InputLayout);


        static D3D10_VIEWPORT vp{};


        {
            int8_t* pBuf = data.data();

            while (((RS::dataheader*)pBuf)->type != RS::datatype::Unknown && pBuf < data.data() + data.size()) {


                if (((RS::dataheader*)pBuf)->type == RS::datatype::DrawVert) {
                    char* VertPtr = (char*)(pBuf + sizeof(RS::dataheader));
                    int VertSize = ((RS::dataheader*)pBuf)->size;

                    if (!G::pVB || G::VertexBufferSize < (int)(VertSize / 20))
                    {
                        if (G::pVB) { G::pVB->Release(); G::pVB = NULL; }
                        G::VertexBufferSize = (int)(VertSize / 20) + 5000;
                        D3D10_BUFFER_DESC desc;
                        memset(&desc, 0, sizeof(D3D10_BUFFER_DESC));
                        desc.Usage = D3D10_USAGE_DYNAMIC;
                        desc.ByteWidth = G::VertexBufferSize * 20;
                        desc.BindFlags = D3D10_BIND_VERTEX_BUFFER;
                        desc.CPUAccessFlags = D3D10_CPU_ACCESS_WRITE;
                        desc.MiscFlags = 0;
                        if (G::pd3dDevice->CreateBuffer(&desc, NULL, &G::pVB) < 0)
                            return;
                    }

                    void* vtx_dst = NULL;
                    if (G::pVB->Map(D3D10_MAP_WRITE_DISCARD, 0, &vtx_dst) == S_OK) {
                        memcpy(vtx_dst, VertPtr, VertSize);
                        G::pVB->Unmap();
                    }

                }

                if (((RS::dataheader*)pBuf)->type == RS::datatype::DrawIdx) {
                    char* IdxPtr = (char*)(pBuf + sizeof(RS::dataheader));
                    int IdxSize = ((RS::dataheader*)pBuf)->size;

                    if (!G::pIB || G::IndexBufferSize < (int)(IdxSize / 2))
                    {
                        if (G::pIB) { G::pIB->Release(); G::pIB = NULL; }
                        G::IndexBufferSize = (int)(IdxSize / 2) + 10000;
                        D3D10_BUFFER_DESC desc;
                        memset(&desc, 0, sizeof(D3D10_BUFFER_DESC));
                        desc.Usage = D3D10_USAGE_DYNAMIC;
                        desc.ByteWidth = G::IndexBufferSize * 2;
                        desc.BindFlags = D3D10_BIND_INDEX_BUFFER;
                        desc.CPUAccessFlags = D3D10_CPU_ACCESS_WRITE;
                        if (G::pd3dDevice->CreateBuffer(&desc, NULL, &G::pIB) < 0)
                            return;
                    }
                    void* idx_dst = NULL;
                    if (G::pIB->Map(D3D10_MAP_WRITE_DISCARD, 0, &idx_dst) == S_OK) {
                        memcpy(idx_dst, IdxPtr, IdxSize);
                        G::pIB->Unmap();
                    }
                }

                if (((RS::dataheader*)pBuf)->type == RS::datatype::VertexConstantBuffer) {
                    {
                        RS::DataVertexConstantBuffer* DataVertexConstantBuffer = (RS::DataVertexConstantBuffer*)(pBuf + sizeof(RS::dataheader));
                        vp = DataVertexConstantBuffer->vp.dx10;

                        struct VERTEX_CONSTANT_BUFFER
                        {
                            float   mvp[4][4];
                        };

                        void* mapped_resource = 0;
                        if (G::pVertexConstantBuffer->Map(D3D10_MAP_WRITE_DISCARD, 0, &mapped_resource) == S_OK) {
                            VERTEX_CONSTANT_BUFFER* constant_buffer = (VERTEX_CONSTANT_BUFFER*)mapped_resource;
                            

                            ID3D10Texture2D* back_buffer = 0;
                            GUID IID_ID3D10Texture2D = { 0x9B7E4C04,0x342C,0x4106,0xA1,0x9F,0x4F,0x27,0x04,0xF6,0x89,0xF0 };
                            G::pd3dSwapChain->GetBuffer(0, IID_ID3D10Texture2D, (void**)&back_buffer);
                            D3D10_TEXTURE2D_DESC back_buffer_desc{};
                            back_buffer->GetDesc(&back_buffer_desc);
                            float L = 0.0F;
                            float R = 0.0F + back_buffer_desc.Width;
                            float T = 0.0F;
                            float B = 0.0F + back_buffer_desc.Height;
                            float mvp[4][4] =
                            {
                                { 2.0f / (R - L),   0.0f,           0.0f,       0.0f },
                                { 0.0f,         2.0f / (T - B),     0.0f,       0.0f },
                                { 0.0f,         0.0f,           0.5f,       0.0f },
                                { (R + L) / (L - R),  (T + B) / (B - T),    0.5f,       1.0f },
                            };
                            memcpy(&constant_buffer->mvp, mvp, sizeof(mvp));
                            G::pVertexConstantBuffer->Unmap();
                            back_buffer->Release();
                        }
                    }

                }

                {
                    G::pd3dDevice->RSSetViewports(1, &vp);

                    // Bind shader and vertex buffers
                    unsigned int stride = 20;
                    unsigned int offset = 0;
                    G::pd3dDevice->IASetInputLayout(G::pInputLayout);
                    G::pd3dDevice->IASetVertexBuffers(0, 1, &G::pVB, &stride, &offset);
                    G::pd3dDevice->IASetIndexBuffer(G::pIB, 2 == 2 ? DXGI_FORMAT_R16_UINT : DXGI_FORMAT_R32_UINT, 0);
                    G::pd3dDevice->IASetPrimitiveTopology(D3D10_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
                    G::pd3dDevice->VSSetShader(G::pVertexShader);
                    G::pd3dDevice->VSSetConstantBuffers(0, 1, &G::pVertexConstantBuffer);
                    G::pd3dDevice->PSSetShader(G::pPixelShader);
                    G::pd3dDevice->PSSetSamplers(0, 1, &G::pFontSampler);
                    G::pd3dDevice->GSSetShader(NULL);

                    // Setup render state
                    const float blend_factor[4] = { 0.f, 0.f, 0.f, 0.f };
                    G::pd3dDevice->OMSetBlendState(G::pBlendState, blend_factor, 0xffffffff);
                    G::pd3dDevice->OMSetDepthStencilState(G::pDepthStencilState, 0);
                    G::pd3dDevice->RSSetState(G::pRasterizerState);
                }


                if (((RS::dataheader*)pBuf)->type == RS::datatype::FunSetScissorRects) {
                    RS::DataSetScissorRects* SetScissorRectsPtr = (RS::DataSetScissorRects*)(pBuf + sizeof(RS::dataheader));

                    G::pd3dDevice->RSSetScissorRects(SetScissorRectsPtr->NumRects, &(SetScissorRectsPtr->rect.dx10));
                }
                if (((RS::dataheader*)pBuf)->type == RS::datatype::FunSetShaderResources) {
                    RS::DataSetShaderResources* SetShaderResourcesPtr = (RS::DataSetShaderResources*)(pBuf + sizeof(RS::dataheader));
                    auto iter = G::pTextureViewMap.find(SetShaderResourcesPtr->TexID);
                    if (iter != G::pTextureViewMap.end()) {
                        auto* pShaderResourceViews = iter->second;
                        G::pd3dDevice->PSSetShaderResources(SetShaderResourcesPtr->StartSlot, SetShaderResourcesPtr->NumViews, &pShaderResourceViews);
                    }
                    else {

                        {
                            auto* CommunicaBuffer = RS::RSFactory::GetInstance().OpenCommunicaBuffer(SetShaderResourcesPtr->TexID);

                            std::vector<int8_t> fontTex;
                            CommunicaBuffer->Download(fontTex);

                            D3D10_TEXTURE2D_DESC desc;
                            ZeroMemory(&desc, sizeof(desc));
                            desc.Width = ((int*)fontTex.data())[0];
                            desc.Height = ((int*)fontTex.data())[1];
                            desc.MipLevels = 1;
                            desc.ArraySize = 1;
                            desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
                            desc.SampleDesc.Count = 1;
                            desc.Usage = D3D10_USAGE_DEFAULT;
                            desc.BindFlags = D3D10_BIND_SHADER_RESOURCE;
                            desc.CPUAccessFlags = 0;
                            auto* pixels = fontTex.data() + (sizeof(int) * 2);
                            ID3D10Texture2D* pTexture = NULL;
                            D3D10_SUBRESOURCE_DATA subResource;
                            subResource.pSysMem = pixels;
                            subResource.SysMemPitch = desc.Width * 4;
                            subResource.SysMemSlicePitch = 0;
                            G::pd3dDevice->CreateTexture2D(&desc, &subResource, &pTexture);


                            // Create texture view
                            D3D10_SHADER_RESOURCE_VIEW_DESC srv_desc;
                            ZeroMemory(&srv_desc, sizeof(srv_desc));
                            srv_desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
                            srv_desc.ViewDimension = D3D10_SRV_DIMENSION_TEXTURE2D;
                            srv_desc.Texture2D.MipLevels = desc.MipLevels;
                            srv_desc.Texture2D.MostDetailedMip = 0;
                            ID3D10ShaderResourceView* pFontTextureView = 0;
                            G::pd3dDevice->CreateShaderResourceView(pTexture, &srv_desc, &pFontTextureView);

                            G::pTextureViewMap.insert({ SetShaderResourcesPtr->TexID, pFontTextureView });

                            G::pd3dDevice->PSSetShaderResources(SetShaderResourcesPtr->StartSlot, SetShaderResourcesPtr->NumViews, &pFontTextureView);

                            pTexture->Release();
                        }

                    }
                }
                if (((RS::dataheader*)pBuf)->type == RS::datatype::FunDataDrawIndexed) {
                    RS::DataDrawIndexed* DrawIndexedPtr = (RS::DataDrawIndexed*)(pBuf + sizeof(RS::dataheader));

                    if(bypass::CanPresent())
                        G::pd3dDevice->DrawIndexed(DrawIndexedPtr->IndexCount, DrawIndexedPtr->StartIndexLocation, DrawIndexedPtr->BaseVertexLocation);

                }


                pBuf += (((RS::dataheader*)pBuf)->size) + sizeof(RS::dataheader);
            }
        }


        G::pd3dDevice->RSSetScissorRects(old.ScissorRectsCount, old.ScissorRects);
        G::pd3dDevice->RSSetViewports(old.ViewportsCount, old.Viewports);
        G::pd3dDevice->RSSetState(old.RS); if (old.RS) old.RS->Release();
        G::pd3dDevice->OMSetBlendState(old.BlendState, old.BlendFactor, old.SampleMask); if (old.BlendState) old.BlendState->Release();
        G::pd3dDevice->OMSetDepthStencilState(old.DepthStencilState, old.StencilRef); if (old.DepthStencilState) old.DepthStencilState->Release();
        G::pd3dDevice->PSSetShaderResources(0, 1, &old.PSShaderResource); if (old.PSShaderResource) old.PSShaderResource->Release();
        G::pd3dDevice->PSSetSamplers(0, 1, &old.PSSampler); if (old.PSSampler) old.PSSampler->Release();
        G::pd3dDevice->PSSetShader(old.PS); if (old.PS) old.PS->Release();
        G::pd3dDevice->VSSetShader(old.VS); if (old.VS) old.VS->Release();
        G::pd3dDevice->GSSetShader(old.GS); if (old.GS) old.GS->Release();
        G::pd3dDevice->VSSetConstantBuffers(0, 1, &old.VSConstantBuffer); if (old.VSConstantBuffer) old.VSConstantBuffer->Release();
        G::pd3dDevice->IASetPrimitiveTopology(old.PrimitiveTopology);
        G::pd3dDevice->IASetIndexBuffer(old.IndexBuffer, old.IndexBufferFormat, old.IndexBufferOffset); if (old.IndexBuffer) old.IndexBuffer->Release();
        G::pd3dDevice->IASetVertexBuffers(0, 1, &old.VertexBuffer, &old.VertexBufferStride, &old.VertexBufferOffset); if (old.VertexBuffer) old.VertexBuffer->Release();
        G::pd3dDevice->IASetInputLayout(old.InputLayout); if (old.InputLayout) old.InputLayout->Release();

    };
}