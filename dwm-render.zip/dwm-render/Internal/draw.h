#pragma once
namespace draw {
    bool init();
    void draw_call();


};