#pragma once
#include <Windows.h>
class IImDataRender {
public:
    // 0xd3d11 0xd3d10
    static IImDataRender *GetInstance(DWORD version);

    virtual bool Init(struct IDXGISwapChain *swapChain)            = 0;
    virtual void RenderData(unsigned char *data, size_t data_size) = 0;

protected:
    static unsigned char vertex_shader[1436];
    static unsigned char pixel_shader[832];
    IImDataRender() {}
    virtual ~IImDataRender() throw() {}
};
