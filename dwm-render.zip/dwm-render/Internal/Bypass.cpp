#include "Bypass.h"
#include "xorstr.hpp"
#include "dwm.h"
#include <windows.h>
#include <Winternl.h>
#include <winevt.h> 
#include <evntprov.h>
#include <array>
#include <string>

namespace bypass{


	inline std::tuple<std::uintptr_t, std::size_t> get_section(std::uintptr_t local_module_base, std::string section_name)
	{
		const auto module_dos_header = reinterpret_cast<PIMAGE_DOS_HEADER>(local_module_base);

		if (module_dos_header->e_magic != IMAGE_DOS_SIGNATURE)
		{
			return{};
		}

		const auto module_nt_headers = reinterpret_cast<PIMAGE_NT_HEADERS>(local_module_base + module_dos_header->e_lfanew);

		if (module_nt_headers->Signature != IMAGE_NT_SIGNATURE)
		{
			return{};
		}
		const auto section_count = module_nt_headers->FileHeader.NumberOfSections;
		const auto section_headers = IMAGE_FIRST_SECTION(module_nt_headers);

		for (WORD i = 0; i < section_count; ++i)
		{
			if (strcmp(reinterpret_cast<char*>(section_headers[i].Name), section_name.c_str()) == 0)
			{
				return { static_cast<std::uintptr_t>(section_headers[i].VirtualAddress) + local_module_base, static_cast<std::uintptr_t>(section_headers[i].Misc.VirtualSize) };
			}
		}

		return {};
	}

	DWORD GetModuleLen(HMODULE hModule)
	{
		PBYTE pImage = (PBYTE)hModule;
		PIMAGE_DOS_HEADER pImageDosHeader;
		PIMAGE_NT_HEADERS pImageNtHeader;
		pImageDosHeader = (PIMAGE_DOS_HEADER)pImage;
		if (pImageDosHeader->e_magic != IMAGE_DOS_SIGNATURE)
		{
			return 0;
		}
		pImageNtHeader = (PIMAGE_NT_HEADERS)&pImage[pImageDosHeader->e_lfanew];
		if (pImageNtHeader->Signature != IMAGE_NT_SIGNATURE)
		{
			return 0;
		}
		return pImageNtHeader->OptionalHeader.SizeOfImage;
	}
	bool CanPresent()
	{
		std::array<std::string,6> dlls = { "d3d11.dll","dxgi.dll","dwmcore.dll" ,"d2d1.dll","dcomp.dll","d3d10warp.dll"};
		for (auto & dllname:dlls) {
			auto base = GetModuleHandleA(dllname.c_str());
			if (base) {
				auto [address, size] = get_section((std::uintptr_t)base, ".text");

				uintptr_t start = (uintptr_t)address;
				uintptr_t end = (uintptr_t)address + (uintptr_t)size;
				uintptr_t mem = start;
				while (mem < end){
					MEMORY_BASIC_INFORMATION mem_info{};
					VirtualQuery((LPCVOID)mem, &mem_info, sizeof mem_info);
					if (mem_info.Protect & PAGE_GUARD ) {
						return false;
					}
					mem += mem_info.RegionSize;
				}
			}
		}
		return true;
	}
}