#include "RenderStream.hpp"
#include "xorstr.hpp"
#include "lazy_importer.hpp"
#include "dwm.h"
#include <string>
#include "Bypass.h"
extern NTSYSAPI NTSTATUS RtlGetVersion(
    PRTL_OSVERSIONINFOW lpVersionInformation
);

DWORD EntryPoint(LPVOID) {

    RTL_OSVERSIONINFOW osversion{};
    LI_FN(RtlGetVersion)(&osversion);

    DWORD init_result = -1;

    if (osversion.dwBuildNumber >= 10240)
        init_result = dwm::win10::init(0);
    else
        init_result = dwm::win7::init(0);

    MSG_LOG("init result 0x%x", init_result);

    return 0;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved) {
    
    if (ul_reason_for_call == DLL_PROCESS_ATTACH) {
        MSG_LOG("DllMain hModule %p", hModule);
        CloseHandle(CreateThread(0, 0, &EntryPoint, 0, 0, 0));
    }

    return TRUE;
}