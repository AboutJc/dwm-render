
#include "CImDataRender.h"
#include "RenderStream.hpp"
#include "CShareBuffer.h"
#include <map>
#include <wrl.h>
#include <xorstr.hpp>
#include <string>
#include "Bypass.h"
#include "dwm.h"
#include <d3d11.h>
#include <d3d10.h>
#include <dxgi.h>

namespace {
template <typename T>
using ComPtr = Microsoft::WRL::ComPtr<T>;
struct BACKUP_DX11_STATE {
    UINT                      ScissorRectsCount, ViewportsCount;
    D3D11_RECT                ScissorRects[D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE];
    D3D11_VIEWPORT            Viewports[D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE];
    ID3D11RasterizerState    *RS;
    ID3D11BlendState         *BlendState;
    FLOAT                     BlendFactor[4];
    UINT                      SampleMask;
    UINT                      StencilRef;
    ID3D11DepthStencilState  *DepthStencilState;
    ID3D11ShaderResourceView *PSShaderResource;
    ID3D11SamplerState       *PSSampler;
    ID3D11PixelShader        *PS;
    ID3D11VertexShader       *VS;
    ID3D11GeometryShader     *GS;
    UINT                      PSInstancesCount, VSInstancesCount, GSInstancesCount;
    ID3D11ClassInstance      *PSInstances[256], *VSInstances[256], *GSInstances[256];
    D3D11_PRIMITIVE_TOPOLOGY  PrimitiveTopology;
    ID3D11Buffer             *IndexBuffer, *VertexBuffer, *VSConstantBuffer;
    UINT                      IndexBufferOffset, VertexBufferStride, VertexBufferOffset;
    DXGI_FORMAT               IndexBufferFormat;
    ID3D11InputLayout        *InputLayout;
};
struct BACKUP_DX10_STATE {
    UINT                      ScissorRectsCount, ViewportsCount;
    D3D10_RECT                ScissorRects[D3D10_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE];
    D3D10_VIEWPORT            Viewports[D3D10_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE];
    ID3D10RasterizerState    *RS;
    ID3D10BlendState         *BlendState;
    FLOAT                     BlendFactor[4];
    UINT                      SampleMask;
    UINT                      StencilRef;
    ID3D10DepthStencilState  *DepthStencilState;
    ID3D10ShaderResourceView *PSShaderResource;
    ID3D10SamplerState       *PSSampler;
    ID3D10PixelShader        *PS;
    ID3D10VertexShader       *VS;
    ID3D10GeometryShader     *GS;
    D3D10_PRIMITIVE_TOPOLOGY  PrimitiveTopology;
    ID3D10Buffer             *IndexBuffer, *VertexBuffer, *VSConstantBuffer;
    UINT                      IndexBufferOffset, VertexBufferStride, VertexBufferOffset;
    DXGI_FORMAT               IndexBufferFormat;
    ID3D10InputLayout        *InputLayout;
};
} // namespace

class CDx11Render : public IImDataRender {
    friend class IImDataRender;

private:
    CDx11Render() {}
    ~CDx11Render() {}

public:
    bool Init(IDXGISwapChain *swapChain) override;
    void RenderData(unsigned char *data, size_t data_size) override;
private:
    std::map<INT64, ID3D11ShaderResourceView *> pTextureViewMap;
    ComPtr<ID3D11Device>                        pd3dDevice;
    ComPtr<ID3D11DeviceContext>                 pd3dDeviceContext;
    ComPtr<IDXGISwapChain>                      pd3dSwapChain;
    ComPtr<IDXGIFactory>                        pFactory;
    ComPtr<ID3D11Buffer>                        pVB;
    ComPtr<ID3D11Buffer>                        pIB;
    ComPtr<ID3D11VertexShader>                  pVertexShader;
    ComPtr<ID3D11InputLayout>                   pInputLayout;
    ComPtr<ID3D11Buffer>                        pVertexConstantBuffer;
    ComPtr<ID3D11PixelShader>                   pPixelShader;
    ComPtr<ID3D11SamplerState>                  pFontSampler;
    ComPtr<ID3D11RasterizerState>               pRasterizerState;
    ComPtr<ID3D11BlendState>                    pBlendState;
    ComPtr<ID3D11DepthStencilState>             pDepthStencilState;
    int                                         VertexBufferSize = 0;
    int                                         IndexBufferSize  = 0;
};

class CDx10Render : public IImDataRender {
    friend class IImDataRender;

private:
    CDx10Render() {}
    ~CDx10Render() {}
public:
    bool Init(IDXGISwapChain *swapChain) override;
    void RenderData(unsigned char *data, size_t data_size) override;

private:
    std::map<INT64, ID3D10ShaderResourceView *> pTextureViewMap;
    ComPtr<ID3D10Device1>                       pd3dDevice;
    ComPtr<IDXGISwapChain>                      pd3dSwapChain;
    ComPtr<IDXGIFactory>                        pFactory;
    ComPtr<ID3D10Buffer>                        pVB;
    ComPtr<ID3D10Buffer>                        pIB;
    ComPtr<ID3D10VertexShader>                  pVertexShader;
    ComPtr<ID3D10InputLayout>                   pInputLayout;
    ComPtr<ID3D10Buffer>                        pVertexConstantBuffer;
    ComPtr<ID3D10PixelShader>                   pPixelShader;
    ComPtr<ID3D10SamplerState>                  pFontSampler;
    ComPtr<ID3D10RasterizerState>               pRasterizerState;
    ComPtr<ID3D10BlendState>                    pBlendState;
    ComPtr<ID3D10DepthStencilState>             pDepthStencilState;
    int                                         VertexBufferSize = 0;
    int                                         IndexBufferSize  = 0;
};

IImDataRender *IImDataRender::GetInstance(DWORD version) {

    if (version == 0xD3D11) {
        static IImDataRender *pointer = nullptr;
        if (!pointer)
            pointer = new CDx11Render();
        return pointer;
    }
    if (version == 0xD3D10) {
        static IImDataRender *pointer = nullptr;
        if (!pointer)
            pointer = new CDx10Render();
        return pointer;
    }
    return nullptr;
}

#undef DEFINE_GUID
#define DEFINE_GUID(name, l, w1, w2, b1, b2, b3, b4, b5, b6, b7, b8)                                                   \
     const GUID name = {l, w1, w2, {b1, b2, b3, b4, b5, b6, b7, b8}}
bool CDx11Render::Init(IDXGISwapChain *swapChain) {
    this->pd3dSwapChain = (swapChain);

    DEFINE_GUID(IID_ID3D11Device, 0xdb6f6ddb, 0xac77, 0x4e88, 0x82, 0x53, 0x81, 0x9d, 0xf9, 0xbb, 0xf1, 0x40);
    auto hr = this->pd3dSwapChain->GetDevice(IID_ID3D11Device,
                                             reinterpret_cast<void **>(this->pd3dDevice.ReleaseAndGetAddressOf()));
    if (hr != S_OK)
        return false;

    this->pd3dDevice->GetImmediateContext(this->pd3dDeviceContext.ReleaseAndGetAddressOf());

    ComPtr<IDXGIDevice>  pDXGIDevice;
    ComPtr<IDXGIAdapter> pDXGIAdapter;

    GUID IID_IDXGIDevice  = {0x54ec77fa, 0x1377, 0x44e6, 0x8c, 0x32, 0x88, 0xfd, 0x5f, 0x44, 0xc8, 0x4c};
    GUID IID_IDXGIAdapter = {0x2411e7e1, 0x12ac, 0x4ccf, 0xbd, 0x14, 0x97, 0x98, 0xe8, 0x53, 0x4d, 0xc0};
    GUID IID_IDXGIFactory = {0x7b7166ec, 0x21c7, 0x44ae, 0xb2, 0x1a, 0xc9, 0xae, 0x32, 0x1a, 0xe3, 0x69};

    if (this->pd3dDevice->QueryInterface(IID_IDXGIDevice, (void **)(pDXGIDevice.ReleaseAndGetAddressOf())) == S_OK) {
        if (pDXGIDevice->GetParent(IID_IDXGIAdapter, (void **)(pDXGIAdapter.ReleaseAndGetAddressOf())) == S_OK) {
            if (pDXGIAdapter->GetParent(IID_IDXGIFactory, (void **)(this->pFactory.ReleaseAndGetAddressOf())) == S_OK) {
            }
        }
    }

    hr =
        this->pd3dDevice->CreateVertexShader(vertex_shader, sizeof(vertex_shader), NULL, this->pVertexShader.ReleaseAndGetAddressOf());
    if (hr != S_OK)
        return false;

    std::string POSITION = xorstr_("POSITION");
    std::string TEXCOORD = xorstr_("TEXCOORD");
    std::string COLOR    = xorstr_("COLOR");

    D3D11_INPUT_ELEMENT_DESC local_layout[] = {
        {POSITION.c_str(), 0, DXGI_FORMAT_R32G32_FLOAT, 0, (UINT)0, D3D11_INPUT_PER_VERTEX_DATA, 0},
        {TEXCOORD.c_str(), 0, DXGI_FORMAT_R32G32_FLOAT, 0, (UINT)8, D3D11_INPUT_PER_VERTEX_DATA, 0},
        {COLOR.c_str(), 0, DXGI_FORMAT_R8G8B8A8_UNORM, 0, (UINT)16, D3D11_INPUT_PER_VERTEX_DATA, 0},
    };

    hr = this->pd3dDevice->CreateInputLayout(local_layout, 3, vertex_shader, sizeof(vertex_shader), this->pInputLayout.ReleaseAndGetAddressOf());
    if (hr != S_OK)
        return false;

    {
        D3D11_BUFFER_DESC desc;
        desc.ByteWidth      = 64;
        desc.Usage          = D3D11_USAGE_DYNAMIC;
        desc.BindFlags      = D3D11_BIND_CONSTANT_BUFFER;
        desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
        desc.MiscFlags      = 0;
        hr                  = this->pd3dDevice->CreateBuffer(&desc, NULL, this->pVertexConstantBuffer.ReleaseAndGetAddressOf());
        if (hr != S_OK)
            return false;
        else
            MSG_LOG("VertexConstantBuffer Created :0x%p", pVertexConstantBuffer.Get());
    }


    hr = this->pd3dDevice->CreatePixelShader(pixel_shader, sizeof(pixel_shader), NULL, this->pPixelShader.ReleaseAndGetAddressOf());
    if (hr != S_OK)
        return false;

    {
        D3D11_BLEND_DESC desc;
        ZeroMemory(&desc, sizeof(desc));
        desc.AlphaToCoverageEnable                 = false;
        desc.RenderTarget[0].BlendEnable           = true;
        desc.RenderTarget[0].SrcBlend              = D3D11_BLEND_SRC_ALPHA;
        desc.RenderTarget[0].DestBlend             = D3D11_BLEND_INV_SRC_ALPHA;
        desc.RenderTarget[0].BlendOp               = D3D11_BLEND_OP_ADD;
        desc.RenderTarget[0].SrcBlendAlpha         = D3D11_BLEND_ONE;
        desc.RenderTarget[0].DestBlendAlpha        = D3D11_BLEND_INV_SRC_ALPHA;
        desc.RenderTarget[0].BlendOpAlpha          = D3D11_BLEND_OP_ADD;
        desc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
        this->pd3dDevice->CreateBlendState(&desc, this->pBlendState.ReleaseAndGetAddressOf());
    }


     // Create the rasterizer state
    {
        D3D11_RASTERIZER_DESC desc;
        ZeroMemory(&desc, sizeof(desc));
        desc.FillMode        = D3D11_FILL_SOLID;
        desc.CullMode        = D3D11_CULL_NONE;
        desc.ScissorEnable   = true;
        desc.DepthClipEnable = true;
        this->pd3dDevice->CreateRasterizerState(&desc, this->pRasterizerState.ReleaseAndGetAddressOf());
    }

    // Create depth-stencil State
    {
        D3D11_DEPTH_STENCIL_DESC desc;
        ZeroMemory(&desc, sizeof(desc));
        desc.DepthEnable             = false;
        desc.DepthWriteMask          = D3D11_DEPTH_WRITE_MASK_ALL;
        desc.DepthFunc               = D3D11_COMPARISON_ALWAYS;
        desc.StencilEnable           = false;
        desc.FrontFace.StencilFailOp = desc.FrontFace.StencilDepthFailOp = desc.FrontFace.StencilPassOp =
            D3D11_STENCIL_OP_KEEP;
        desc.FrontFace.StencilFunc = D3D11_COMPARISON_ALWAYS;
        desc.BackFace              = desc.FrontFace;
        this->pd3dDevice->CreateDepthStencilState(&desc, this->pDepthStencilState.ReleaseAndGetAddressOf());
    }

    MSG_LOG("CDx11Render::Init End: true");

    return true;
}
void CDx11Render::RenderData(unsigned char *data, size_t data_size) {
    //MSG_LOG("CDx11Render::RenderData");
    BACKUP_DX11_STATE old = {};
    old.ScissorRectsCount = old.ViewportsCount = D3D11_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE;
    this->pd3dDeviceContext->RSGetScissorRects(&old.ScissorRectsCount, old.ScissorRects);
    this->pd3dDeviceContext->RSGetViewports(&old.ViewportsCount, old.Viewports);
    this->pd3dDeviceContext->RSGetState(&old.RS);
    this->pd3dDeviceContext->OMGetBlendState(&old.BlendState, old.BlendFactor, &old.SampleMask);
    this->pd3dDeviceContext->OMGetDepthStencilState(&old.DepthStencilState, &old.StencilRef);
    this->pd3dDeviceContext->PSGetShaderResources(0, 1, &old.PSShaderResource);
    this->pd3dDeviceContext->PSGetSamplers(0, 1, &old.PSSampler);
    old.PSInstancesCount = old.VSInstancesCount = old.GSInstancesCount = 256;
    this->pd3dDeviceContext->PSGetShader(&old.PS, old.PSInstances, &old.PSInstancesCount);
    this->pd3dDeviceContext->VSGetShader(&old.VS, old.VSInstances, &old.VSInstancesCount);
    this->pd3dDeviceContext->VSGetConstantBuffers(0, 1, &old.VSConstantBuffer);
    this->pd3dDeviceContext->GSGetShader(&old.GS, old.GSInstances, &old.GSInstancesCount);
    this->pd3dDeviceContext->IAGetPrimitiveTopology(&old.PrimitiveTopology);
    this->pd3dDeviceContext->IAGetIndexBuffer(&old.IndexBuffer, &old.IndexBufferFormat, &old.IndexBufferOffset);
    this->pd3dDeviceContext->IAGetVertexBuffers(
        0, 1, &old.VertexBuffer, &old.VertexBufferStride, &old.VertexBufferOffset);
    this->pd3dDeviceContext->IAGetInputLayout(&old.InputLayout);
    static D3D11_VIEWPORT vp{};

    namespace RS = RenderStream;
    {
        for (uintptr_t pBuf = reinterpret_cast<uintptr_t>(data); pBuf < reinterpret_cast<uintptr_t>(data + data_size);
             pBuf += static_cast<uintptr_t>(((RS::dataheader *)pBuf)->size) + sizeof(RS::dataheader)) {

            if (((RS::dataheader *)pBuf)->type == RS::datatype::Unknown) {
                break;
            }

            if (((RS::dataheader *)pBuf)->type == RS::datatype::FunSetShaderResources) {
                INT64 combination_handle = ((RS::DataSetShaderResources *)(pBuf + sizeof(RS::dataheader)))->TexID;
                if (this->pTextureViewMap.find(combination_handle) != this->pTextureViewMap.end()) {
                    continue;
                }
                MSG_LOG("new Shader Resource Texture View");
                //__debugbreak();
                auto *CommunicaBuffer = IRSFactory::GetInstance()->OpenShareBuffer(combination_handle);

                if (!CommunicaBuffer)
                    continue;

                CommunicaBuffer->Download();

                D3D11_TEXTURE2D_DESC desc;
                ZeroMemory(&desc, sizeof(desc));
                desc.Width                      = ((int *)CommunicaBuffer->Data())[0];
                desc.Height                     = ((int *)CommunicaBuffer->Data())[1];
                desc.MipLevels                  = 1;
                desc.ArraySize                  = 1;
                desc.Format                     = DXGI_FORMAT_R8G8B8A8_UNORM;
                desc.SampleDesc.Count           = 1;
                desc.Usage                      = D3D11_USAGE_DEFAULT;
                desc.BindFlags                  = D3D11_BIND_SHADER_RESOURCE;
                desc.CPUAccessFlags             = 0;
                auto *                 pixels   = CommunicaBuffer->Data() + (sizeof(int) * 2);
                ID3D11Texture2D *      pTexture = NULL;
                D3D11_SUBRESOURCE_DATA subResource;
                subResource.pSysMem          = pixels;
                subResource.SysMemPitch      = desc.Width * 4;
                subResource.SysMemSlicePitch = 0;
                this->pd3dDevice->CreateTexture2D(&desc, &subResource, &pTexture);

                // Create texture view
                D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc;
                ZeroMemory(&srvDesc, sizeof(srvDesc));
                srvDesc.Format                    = DXGI_FORMAT_R8G8B8A8_UNORM;
                srvDesc.ViewDimension             = D3D11_SRV_DIMENSION_TEXTURE2D;
                srvDesc.Texture2D.MipLevels       = desc.MipLevels;
                srvDesc.Texture2D.MostDetailedMip = 0;

                ID3D11ShaderResourceView *pFontTextureView = 0;
                this->pd3dDevice->CreateShaderResourceView(pTexture, &srvDesc, &pFontTextureView);
                this->pTextureViewMap.insert({combination_handle, pFontTextureView});
                pTexture->Release();

                if (!this->pFontSampler) {
                    D3D11_SAMPLER_DESC desc;
                    ZeroMemory(&desc, sizeof(desc));
                    desc.Filter         = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
                    desc.AddressU       = D3D11_TEXTURE_ADDRESS_WRAP;
                    desc.AddressV       = D3D11_TEXTURE_ADDRESS_WRAP;
                    desc.AddressW       = D3D11_TEXTURE_ADDRESS_WRAP;
                    desc.MipLODBias     = 0.f;
                    desc.ComparisonFunc = D3D11_COMPARISON_ALWAYS;
                    desc.MinLOD         = 0.f;
                    desc.MaxLOD         = 0.f;
                    this->pd3dDevice->CreateSamplerState(&desc, this->pFontSampler.ReleaseAndGetAddressOf());
                }
            }
            if (((RS::dataheader *)pBuf)->type == RS::datatype::DrawVert) {
                char *VertPtr  = (char *)(pBuf + sizeof(RS::dataheader));
                int   VertSize = ((RS::dataheader *)pBuf)->size;

                if (!pVB || this->VertexBufferSize < (int)(VertSize / 20)) {
                    if (pVB) {
                        pVB.Reset();
                    }
                    VertexBufferSize = (int)(VertSize / 20) + 5000;
                    D3D11_BUFFER_DESC desc;
                    memset(&desc, 0, sizeof(D3D11_BUFFER_DESC));
                    desc.Usage          = D3D11_USAGE_DYNAMIC;
                    desc.ByteWidth      = VertexBufferSize * 20;
                    desc.BindFlags      = D3D11_BIND_VERTEX_BUFFER;
                    desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
                    desc.MiscFlags      = 0;
                    if (pd3dDevice->CreateBuffer(&desc, NULL, &pVB) < 0)
                        return;
                }

                D3D11_MAPPED_SUBRESOURCE vtx_resource{};
                if (pd3dDeviceContext->Map(pVB.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &vtx_resource) == S_OK) {
                    memcpy(vtx_resource.pData, VertPtr, VertSize);
                    pd3dDeviceContext->Unmap(pVB.Get(), 0);
                }
            }
            if (((RS::dataheader *)pBuf)->type == RS::datatype::DrawIdx) {
                char *IdxPtr  = (char *)(pBuf + sizeof(RS::dataheader));
                int   IdxSize = ((RS::dataheader *)pBuf)->size;

                if (!pIB || IndexBufferSize < (int)(IdxSize / 2)) {
                    if (pIB) {
                        pIB.Reset();
                    }
                    IndexBufferSize = (int)(IdxSize / 2) + 10000;
                    D3D11_BUFFER_DESC desc;
                    memset(&desc, 0, sizeof(D3D11_BUFFER_DESC));
                    desc.Usage          = D3D11_USAGE_DYNAMIC;
                    desc.ByteWidth      = IndexBufferSize * 2;
                    desc.BindFlags      = D3D11_BIND_INDEX_BUFFER;
                    desc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
                    if (pd3dDevice->CreateBuffer(&desc, NULL, &pIB) < 0)
                        return;
                }

                D3D11_MAPPED_SUBRESOURCE idx_resource{};
                if (pd3dDeviceContext->Map(pIB.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &idx_resource) == S_OK) {
                    memcpy(idx_resource.pData, IdxPtr, IdxSize);
                    pd3dDeviceContext->Unmap(pIB.Get(), 0);
                }
            }
            if (((RS::dataheader *)pBuf)->type == RS::datatype::VertexConstantBuffer) {
                {
                    RS::DataVertexConstantBuffer *DataVertexConstantBuffer =
                        (RS::DataVertexConstantBuffer *)(pBuf + sizeof(RS::dataheader));

                    memcpy(&vp, &(DataVertexConstantBuffer->vp.dx11), sizeof(vp));

                    struct VERTEX_CONSTANT_BUFFER {
                        float mvp[4][4];
                    };

                    D3D11_MAPPED_SUBRESOURCE mapped_resource;
                    if (pd3dDeviceContext->Map(
                            pVertexConstantBuffer.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &mapped_resource) != S_OK)
                        return;
                    VERTEX_CONSTANT_BUFFER *constant_buffer = (VERTEX_CONSTANT_BUFFER *)mapped_resource.pData;

                    ID3D11Texture2D *back_buffer         = 0;
                    GUID             IID_ID3D11Texture2D = {0x6f15aaf2, 0xd208, 0x4e89, 0x9a, 0xb4, 0x48,
                                                0x95,       0x35,   0xd3,   0x4f, 0x9c};
                    pd3dSwapChain->GetBuffer(0, IID_ID3D11Texture2D, (void **)&back_buffer);
                    D3D11_TEXTURE2D_DESC back_buffer_desc{};
                    back_buffer->GetDesc(&back_buffer_desc);
                    float L         = 0.0F;
                    float R         = 0.0F + back_buffer_desc.Width;
                    float T         = 0.0F;
                    float B         = 0.0F + back_buffer_desc.Height;
                    float mvp[4][4] = {
                        {2.0f / (R - L), 0.0f, 0.0f, 0.0f},
                        {0.0f, 2.0f / (T - B), 0.0f, 0.0f},
                        {0.0f, 0.0f, 0.5f, 0.0f},
                        {(R + L) / (L - R), (T + B) / (B - T), 0.5f, 1.0f},
                    };
                    memcpy(&constant_buffer->mvp, mvp, sizeof(mvp));
                    pd3dDeviceContext->Unmap(pVertexConstantBuffer.Get(), 0);
                    back_buffer->Release();
                }
            }
        }
    } // namespace ;

    {
        pd3dDeviceContext->RSSetViewports(1, &vp);
        unsigned int stride = 20;
        unsigned int offset = 0;
        pd3dDeviceContext->IASetInputLayout(pInputLayout.Get());
        ID3D11Buffer *pVb = this->pVB.Get();
        pd3dDeviceContext->IASetVertexBuffers(0, 1, &pVb, &stride, &offset);
        pd3dDeviceContext->IASetIndexBuffer(pIB.Get(), 2 == 2 ? DXGI_FORMAT_R16_UINT : DXGI_FORMAT_R32_UINT, 0);
        pd3dDeviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
        pd3dDeviceContext->VSSetShader(pVertexShader.Get(), NULL, 0);
        auto *pVertexConstantBuffer = this->pVertexConstantBuffer.Get();
        pd3dDeviceContext->VSSetConstantBuffers(0, 1, &pVertexConstantBuffer);
        pd3dDeviceContext->PSSetShader(pPixelShader.Get(), NULL, 0);
        auto *pFontSampler = this->pFontSampler.Get();
        pd3dDeviceContext->PSSetSamplers(0, 1, &pFontSampler);
        pd3dDeviceContext->GSSetShader(NULL, NULL, 0);
        pd3dDeviceContext->HSSetShader(
            NULL, NULL, 0); // In theory we should backup and restore this as well.. very infrequently used..
        pd3dDeviceContext->DSSetShader(
            NULL, NULL, 0); // In theory we should backup and restore this as well.. very infrequently used..
        pd3dDeviceContext->CSSetShader(
            NULL, NULL, 0); // In theory we should backup and restore this as well.. very infrequently used..

        const float blend_factor[4] = {0.f, 0.f, 0.f, 0.f};
        pd3dDeviceContext->OMSetBlendState(pBlendState.Get(), blend_factor, 0xffffffff);
        pd3dDeviceContext->OMSetDepthStencilState(pDepthStencilState.Get(), 0);
        pd3dDeviceContext->RSSetState(pRasterizerState.Get());
    }

     for (uintptr_t pBuf = reinterpret_cast<uintptr_t>(data); pBuf < reinterpret_cast<uintptr_t>(data + data_size);
         pBuf += static_cast<uintptr_t>(((RS::dataheader *)pBuf)->size) + sizeof(RS::dataheader)) {

        if (((RS::dataheader *)pBuf)->type == RS::datatype::Unknown) {
             break;
        }
        if (((RS::dataheader *)pBuf)->type == RS::datatype::FunSetScissorRects) {
            RS::DataSetScissorRects *SetScissorRectsPtr = (RS::DataSetScissorRects *)(pBuf + sizeof(RS::dataheader));
            pd3dDeviceContext->RSSetScissorRects(SetScissorRectsPtr->NumRects, &(SetScissorRectsPtr->rect.dx11));
        }
        if (((RS::dataheader *)pBuf)->type == RS::datatype::FunSetShaderResources) {
            RS::DataSetShaderResources *SetShaderResourcesPtr =
                (RS::DataSetShaderResources *)(pBuf + sizeof(RS::dataheader));
            auto *pShaderResourceViews = pTextureViewMap[SetShaderResourcesPtr->TexID];
            pd3dDeviceContext->PSSetShaderResources(
                SetShaderResourcesPtr->StartSlot, SetShaderResourcesPtr->NumViews, &pShaderResourceViews);
        }
        if (((RS::dataheader *)pBuf)->type == RS::datatype::FunDataDrawIndexed) {
            RS::DataDrawIndexed *DrawIndexedPtr = (RS::DataDrawIndexed *)(pBuf + sizeof(RS::dataheader));

            if (bypass::CanPresent())
                pd3dDeviceContext->DrawIndexed(
                    DrawIndexedPtr->IndexCount, DrawIndexedPtr->StartIndexLocation, DrawIndexedPtr->BaseVertexLocation);
        }
    }

    this->pd3dDeviceContext->RSSetScissorRects(old.ScissorRectsCount, old.ScissorRects);
    this->pd3dDeviceContext->RSSetViewports(old.ViewportsCount, old.Viewports);
    this->pd3dDeviceContext->RSSetState(old.RS);
    if (old.RS)
        old.RS->Release();
    this->pd3dDeviceContext->OMSetBlendState(old.BlendState, old.BlendFactor, old.SampleMask);
    if (old.BlendState)
        old.BlendState->Release();
    this->pd3dDeviceContext->OMSetDepthStencilState(old.DepthStencilState, old.StencilRef);
    if (old.DepthStencilState)
        old.DepthStencilState->Release();
    this->pd3dDeviceContext->PSSetShaderResources(0, 1, &old.PSShaderResource);
    if (old.PSShaderResource)
        old.PSShaderResource->Release();
    this->pd3dDeviceContext->PSSetSamplers(0, 1, &old.PSSampler);
    if (old.PSSampler)
        old.PSSampler->Release();
    this->pd3dDeviceContext->PSSetShader(old.PS, old.PSInstances, old.PSInstancesCount);
    if (old.PS)
        old.PS->Release();
    for (UINT i = 0; i < old.PSInstancesCount; i++)
        if (old.PSInstances[i])
            old.PSInstances[i]->Release();
    this->pd3dDeviceContext->VSSetShader(old.VS, old.VSInstances, old.VSInstancesCount);
    if (old.VS)
        old.VS->Release();
    this->pd3dDeviceContext->VSSetConstantBuffers(0, 1, &old.VSConstantBuffer);
    if (old.VSConstantBuffer)
        old.VSConstantBuffer->Release();
    this->pd3dDeviceContext->GSSetShader(old.GS, old.GSInstances, old.GSInstancesCount);
    if (old.GS)
        old.GS->Release();
    for (UINT i = 0; i < old.VSInstancesCount; i++)
        if (old.VSInstances[i])
            old.VSInstances[i]->Release();
    this->pd3dDeviceContext->IASetPrimitiveTopology(old.PrimitiveTopology);
    this->pd3dDeviceContext->IASetIndexBuffer(old.IndexBuffer, old.IndexBufferFormat, old.IndexBufferOffset);
    if (old.IndexBuffer)
        old.IndexBuffer->Release();
    this->pd3dDeviceContext->IASetVertexBuffers(
        0, 1, &old.VertexBuffer, &old.VertexBufferStride, &old.VertexBufferOffset);
    if (old.VertexBuffer)
        old.VertexBuffer->Release();
    this->pd3dDeviceContext->IASetInputLayout(old.InputLayout);
    if (old.InputLayout)
        old.InputLayout->Release();
}
bool CDx10Render::Init(IDXGISwapChain *swapChain) { 
    this->pd3dSwapChain = swapChain;

    DEFINE_GUID(IID_ID3D10Device, 0x9B7E4C0F, 0x342C, 0x4106, 0xA1, 0x9F, 0x4F, 0x27, 0x04, 0xF6, 0x89, 0xF0);
    auto hr = this->pd3dSwapChain->GetDevice(IID_ID3D10Device, (void **)this->pd3dDevice.ReleaseAndGetAddressOf());

    if (hr != S_OK)
        return false;



    IDXGIDevice * pDXGIDevice  = NULL;
    IDXGIAdapter *pDXGIAdapter = NULL;

    GUID IID_IDXGIDevice  = {0x54ec77fa, 0x1377, 0x44e6, 0x8c, 0x32, 0x88, 0xfd, 0x5f, 0x44, 0xc8, 0x4c};
    GUID IID_IDXGIAdapter = {0x2411e7e1, 0x12ac, 0x4ccf, 0xbd, 0x14, 0x97, 0x98, 0xe8, 0x53, 0x4d, 0xc0};
    GUID IID_IDXGIFactory = {0x7b7166ec, 0x21c7, 0x44ae, 0xb2, 0x1a, 0xc9, 0xae, 0x32, 0x1a, 0xe3, 0x69};

    if (this->pd3dDevice->QueryInterface(IID_IDXGIDevice, (void **)(&pDXGIDevice)) == S_OK) {
        if (pDXGIDevice->GetParent(IID_IDXGIAdapter, (void **)(&pDXGIAdapter)) == S_OK) {
            if (pDXGIAdapter->GetParent(IID_IDXGIFactory, (void **)(pFactory.ReleaseAndGetAddressOf())) == S_OK) {
            }
        }
    }

    if (pDXGIDevice)
        pDXGIDevice->Release();
    if (pDXGIAdapter)
        pDXGIAdapter->Release();


    {
        auto hr = this->pd3dDevice->CreateVertexShader(vertex_shader, sizeof(vertex_shader),this->pVertexShader.ReleaseAndGetAddressOf());
        if (hr != S_OK)
            return false;
        std::string POSITION = xorstr_("POSITION");
        std::string TEXCOORD = xorstr_("TEXCOORD");
        std::string COLOR    = xorstr_("COLOR");
        // Create the input layout
        D3D10_INPUT_ELEMENT_DESC local_layout[] = {
            {POSITION.c_str(), 0, DXGI_FORMAT_R32G32_FLOAT, 0, (UINT)0, D3D10_INPUT_PER_VERTEX_DATA, 0},
            {TEXCOORD.c_str(), 0, DXGI_FORMAT_R32G32_FLOAT, 0, (UINT)8, D3D10_INPUT_PER_VERTEX_DATA, 0},
            {COLOR.c_str(), 0, DXGI_FORMAT_R8G8B8A8_UNORM, 0, (UINT)16, D3D10_INPUT_PER_VERTEX_DATA, 0},
        };

        hr = this->pd3dDevice->CreateInputLayout(
            local_layout, 3, vertex_shader, sizeof(vertex_shader), this->pInputLayout.ReleaseAndGetAddressOf());
        if (hr != S_OK)
            return false;

        // Create the constant buffer
        {
            D3D10_BUFFER_DESC desc;
            desc.ByteWidth      = 64;
            desc.Usage          = D3D10_USAGE_DYNAMIC;
            desc.BindFlags      = D3D10_BIND_CONSTANT_BUFFER;
            desc.CPUAccessFlags = D3D10_CPU_ACCESS_WRITE;
            desc.MiscFlags      = 0;
            hr                  = this->pd3dDevice->CreateBuffer(&desc, NULL, this->pVertexConstantBuffer.ReleaseAndGetAddressOf());
            if (hr != S_OK)
                return false;
        }
    }

    {
        auto hr = this->pd3dDevice->CreatePixelShader(pixel_shader, sizeof(pixel_shader), this->pPixelShader.ReleaseAndGetAddressOf());
        if (hr != S_OK)
            return false;
    }

    // Create the blending setup
    {
        D3D10_BLEND_DESC desc;
        ZeroMemory(&desc, sizeof(desc));
        desc.AlphaToCoverageEnable    = false;
        desc.BlendEnable[0]           = true;
        desc.SrcBlend                 = D3D10_BLEND_SRC_ALPHA;
        desc.DestBlend                = D3D10_BLEND_INV_SRC_ALPHA;
        desc.BlendOp                  = D3D10_BLEND_OP_ADD;
        desc.SrcBlendAlpha            = D3D10_BLEND_ONE;
        desc.DestBlendAlpha           = D3D10_BLEND_INV_SRC_ALPHA;
        desc.BlendOpAlpha             = D3D10_BLEND_OP_ADD;
        desc.RenderTargetWriteMask[0] = D3D10_COLOR_WRITE_ENABLE_ALL;

        if (this->pd3dDevice->GetFeatureLevel() == D3D10_FEATURE_LEVEL_9_3) {
            desc.BlendEnable[1] = true;
            desc.BlendEnable[2] = true;
            desc.BlendEnable[3] = true;
            desc.BlendEnable[4] = true;
            desc.BlendEnable[5] = true;
            desc.BlendEnable[6] = true;
            desc.BlendEnable[7] = true;
        }

        this->pd3dDevice->CreateBlendState(&desc, this->pBlendState.ReleaseAndGetAddressOf());
    }

    // Create the rasterizer state
    {
        D3D10_RASTERIZER_DESC desc;
        ZeroMemory(&desc, sizeof(desc));
        desc.FillMode        = D3D10_FILL_SOLID;
        desc.CullMode        = D3D10_CULL_NONE;
        desc.ScissorEnable   = true;
        desc.DepthClipEnable = true;
        this->pd3dDevice->CreateRasterizerState(&desc, this->pRasterizerState.ReleaseAndGetAddressOf());
    }

    // Create depth-stencil State
    {
        D3D10_DEPTH_STENCIL_DESC desc;
        ZeroMemory(&desc, sizeof(desc));
        desc.DepthEnable             = false;
        desc.DepthWriteMask          = D3D10_DEPTH_WRITE_MASK_ALL;
        desc.DepthFunc               = D3D10_COMPARISON_ALWAYS;
        desc.StencilEnable           = false;
        desc.FrontFace.StencilFailOp = desc.FrontFace.StencilDepthFailOp = desc.FrontFace.StencilPassOp =
            D3D10_STENCIL_OP_KEEP;
        desc.FrontFace.StencilFunc = D3D10_COMPARISON_ALWAYS;
        desc.BackFace              = desc.FrontFace;
        this->pd3dDevice->CreateDepthStencilState(&desc, this->pDepthStencilState.ReleaseAndGetAddressOf());
    }

    return true;
}
void CDx10Render::RenderData(unsigned char *data, size_t data_size) {
    BACKUP_DX10_STATE old = {};
    old.ScissorRectsCount = old.ViewportsCount = D3D10_VIEWPORT_AND_SCISSORRECT_OBJECT_COUNT_PER_PIPELINE;
    this->pd3dDevice->RSGetScissorRects(&old.ScissorRectsCount, old.ScissorRects);
    this->pd3dDevice->RSGetViewports(&old.ViewportsCount, old.Viewports);
    this->pd3dDevice->RSGetState(&old.RS);
    this->pd3dDevice->OMGetBlendState(&old.BlendState, old.BlendFactor, &old.SampleMask);
    this->pd3dDevice->OMGetDepthStencilState(&old.DepthStencilState, &old.StencilRef);
    this->pd3dDevice->PSGetShaderResources(0, 1, &old.PSShaderResource);
    this->pd3dDevice->PSGetSamplers(0, 1, &old.PSSampler);
    this->pd3dDevice->PSGetShader(&old.PS);
    this->pd3dDevice->VSGetShader(&old.VS);
    this->pd3dDevice->VSGetConstantBuffers(0, 1, &old.VSConstantBuffer);
    this->pd3dDevice->GSGetShader(&old.GS);
    this->pd3dDevice->IAGetPrimitiveTopology(&old.PrimitiveTopology);
    this->pd3dDevice->IAGetIndexBuffer(&old.IndexBuffer, &old.IndexBufferFormat, &old.IndexBufferOffset);
    this->pd3dDevice->IAGetVertexBuffers(0, 1, &old.VertexBuffer, &old.VertexBufferStride, &old.VertexBufferOffset);
    this->pd3dDevice->IAGetInputLayout(&old.InputLayout);
    static D3D10_VIEWPORT vp{};
    namespace RS = RenderStream;
    for (uintptr_t pBuf = reinterpret_cast<uintptr_t>(data); pBuf < reinterpret_cast<uintptr_t>(data + data_size);
         pBuf += static_cast<uintptr_t>(((RS::dataheader *)pBuf)->size) + sizeof(RS::dataheader)) {

        if (((RS::dataheader *)pBuf)->type == RS::datatype::Unknown) {
            break;
        }

        if (((RS::dataheader *)pBuf)->type == RS::datatype::FunSetShaderResources) {
            INT64 combination_handle = ((RS::DataSetShaderResources *)(pBuf + sizeof(RS::dataheader)))->TexID;
            if (this->pTextureViewMap.find(combination_handle) != this->pTextureViewMap.end()) {
                continue;
            }
            MSG_LOG("new Shader Resource Texture View");

            auto *CommunicaBuffer = IRSFactory::GetInstance()->OpenShareBuffer(combination_handle);

            if (!CommunicaBuffer)
                continue;

            CommunicaBuffer->Download();

            D3D10_TEXTURE2D_DESC desc;
            ZeroMemory(&desc, sizeof(desc));
            desc.Width                      = ((int *)CommunicaBuffer->Data())[0];
            desc.Height                     = ((int *)CommunicaBuffer->Data())[1];
            desc.MipLevels                  = 1;
            desc.ArraySize                  = 1;
            desc.Format                     = DXGI_FORMAT_R8G8B8A8_UNORM;
            desc.SampleDesc.Count           = 1;
            desc.Usage                      = D3D10_USAGE_DEFAULT;
            desc.BindFlags                  = D3D10_BIND_SHADER_RESOURCE;
            desc.CPUAccessFlags             = 0;
            auto *                 pixels   = CommunicaBuffer->Data() + (sizeof(int) * 2);
            ID3D10Texture2D *      pTexture = NULL;
            D3D10_SUBRESOURCE_DATA subResource;
            subResource.pSysMem          = pixels;
            subResource.SysMemPitch      = desc.Width * 4;
            subResource.SysMemSlicePitch = 0;
            this->pd3dDevice->CreateTexture2D(&desc, &subResource, &pTexture);

            // Create texture view
            D3D10_SHADER_RESOURCE_VIEW_DESC srv_desc;
            ZeroMemory(&srv_desc, sizeof(srv_desc));
            srv_desc.Format                            = DXGI_FORMAT_R8G8B8A8_UNORM;
            srv_desc.ViewDimension                     = D3D10_SRV_DIMENSION_TEXTURE2D;
            srv_desc.Texture2D.MipLevels               = desc.MipLevels;
            srv_desc.Texture2D.MostDetailedMip         = 0;
            ID3D10ShaderResourceView *pFontTextureView = 0;
            this->pd3dDevice->CreateShaderResourceView(pTexture, &srv_desc, &pFontTextureView);
            pTexture->Release();

            this->pTextureViewMap.insert({combination_handle, pFontTextureView});

            if (!this->pFontSampler) {
                D3D10_SAMPLER_DESC desc;
                ZeroMemory(&desc, sizeof(desc));
                desc.Filter         = D3D10_FILTER_MIN_MAG_MIP_LINEAR;
                desc.AddressU       = D3D10_TEXTURE_ADDRESS_WRAP;
                desc.AddressV       = D3D10_TEXTURE_ADDRESS_WRAP;
                desc.AddressW       = D3D10_TEXTURE_ADDRESS_WRAP;
                desc.MipLODBias     = 0.f;
                desc.ComparisonFunc = D3D10_COMPARISON_ALWAYS;
                desc.MinLOD         = 0.f;
                desc.MaxLOD         = 0.f;

                if (this->pd3dDevice->GetFeatureLevel() == D3D10_FEATURE_LEVEL_9_3) {
                    desc.MaxLOD = FLT_MAX;
                }
                this->pd3dDevice->CreateSamplerState(&desc, this->pFontSampler.ReleaseAndGetAddressOf());
            }
        }
        if (((RS::dataheader *)pBuf)->type == RS::datatype::DrawVert) {
            char *VertPtr  = (char *)(pBuf + sizeof(RS::dataheader));
            int   VertSize = ((RS::dataheader *)pBuf)->size;

            if (!this->pVB || this->VertexBufferSize < (int)(VertSize / 20)) {
                this->pVB.Reset();
                this->VertexBufferSize = (int)(VertSize / 20) + 5000;
                D3D10_BUFFER_DESC desc;
                memset(&desc, 0, sizeof(D3D10_BUFFER_DESC));
                desc.Usage          = D3D10_USAGE_DYNAMIC;
                desc.ByteWidth      = this->VertexBufferSize * 20;
                desc.BindFlags      = D3D10_BIND_VERTEX_BUFFER;
                desc.CPUAccessFlags = D3D10_CPU_ACCESS_WRITE;
                desc.MiscFlags      = 0;
                if (this->pd3dDevice->CreateBuffer(&desc, NULL, this->pVB.ReleaseAndGetAddressOf()) < 0)
                    return;
            }

            void *vtx_dst = NULL;
            if (this->pVB->Map(D3D10_MAP_WRITE_DISCARD, 0, &vtx_dst) == S_OK) {
                memcpy(vtx_dst, VertPtr, VertSize);
                this->pVB->Unmap();
            }
        }
        if (((RS::dataheader *)pBuf)->type == RS::datatype::DrawIdx) {
            char *IdxPtr  = (char *)(pBuf + sizeof(RS::dataheader));
            int   IdxSize = ((RS::dataheader *)pBuf)->size;

            if (!this->pIB || this->IndexBufferSize < (int)(IdxSize / 2)) {
                this->pIB.Reset();
                this->IndexBufferSize = (int)(IdxSize / 2) + 10000;
                D3D10_BUFFER_DESC desc;
                memset(&desc, 0, sizeof(D3D10_BUFFER_DESC));
                desc.Usage          = D3D10_USAGE_DYNAMIC;
                desc.ByteWidth      = this->IndexBufferSize * 2;
                desc.BindFlags      = D3D10_BIND_INDEX_BUFFER;
                desc.CPUAccessFlags = D3D10_CPU_ACCESS_WRITE;
                if (this->pd3dDevice->CreateBuffer(&desc, NULL, this->pIB.ReleaseAndGetAddressOf()) < 0)
                    return;
            }
            void *idx_dst = NULL;
            if (this->pIB->Map(D3D10_MAP_WRITE_DISCARD, 0, &idx_dst) == S_OK) {
                memcpy(idx_dst, IdxPtr, IdxSize);
                this->pIB->Unmap();
            }
        }
        if (((RS::dataheader *)pBuf)->type == RS::datatype::VertexConstantBuffer) {
            RS::DataVertexConstantBuffer *DataVertexConstantBuffer =
                (RS::DataVertexConstantBuffer *)(pBuf + sizeof(RS::dataheader));

            memcpy(&vp, &(DataVertexConstantBuffer->vp.dx10), sizeof(vp));

            struct VERTEX_CONSTANT_BUFFER {
                float mvp[4][4];
            };

            void *mapped_resource = 0;
            if (this->pVertexConstantBuffer->Map(D3D10_MAP_WRITE_DISCARD, 0, &mapped_resource) == S_OK) {
                VERTEX_CONSTANT_BUFFER *constant_buffer = (VERTEX_CONSTANT_BUFFER *)mapped_resource;

                ID3D10Texture2D *back_buffer = 0;
                GUID IID_ID3D10Texture2D = {0x9B7E4C04, 0x342C, 0x4106, 0xA1, 0x9F, 0x4F, 0x27, 0x04, 0xF6, 0x89, 0xF0};
                this->pd3dSwapChain->GetBuffer(0, IID_ID3D10Texture2D, (void **)&back_buffer);
                D3D10_TEXTURE2D_DESC back_buffer_desc{};
                back_buffer->GetDesc(&back_buffer_desc);
                float L         = 0.0F;
                float R         = 0.0F + back_buffer_desc.Width;
                float T         = 0.0F;
                float B         = 0.0F + back_buffer_desc.Height;
                float mvp[4][4] = {
                    {2.0f / (R - L), 0.0f, 0.0f, 0.0f},
                    {0.0f, 2.0f / (T - B), 0.0f, 0.0f},
                    {0.0f, 0.0f, 0.5f, 0.0f},
                    {(R + L) / (L - R), (T + B) / (B - T), 0.5f, 1.0f},
                };
                memcpy(&constant_buffer->mvp, mvp, sizeof(mvp));
                this->pVertexConstantBuffer->Unmap();
                back_buffer->Release();
            }
        }
    }

    this->pd3dDevice->RSSetViewports(1, &vp);

    // Bind shader and vertex buffers
    unsigned int stride = 20;
    unsigned int offset = 0;
    this->pd3dDevice->IASetInputLayout(this->pInputLayout.Get());
    auto *pVB = this->pVB.Get();
    this->pd3dDevice->IASetVertexBuffers(0, 1, &pVB, &stride, &offset);
    this->pd3dDevice->IASetIndexBuffer(this->pIB.Get(), 2 == 2 ? DXGI_FORMAT_R16_UINT : DXGI_FORMAT_R32_UINT, 0);
    this->pd3dDevice->IASetPrimitiveTopology(D3D10_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    this->pd3dDevice->VSSetShader(this->pVertexShader.Get());
    auto *pVertexConstantBuffer = this->pVertexConstantBuffer.Get();
    this->pd3dDevice->VSSetConstantBuffers(0, 1, &pVertexConstantBuffer);
    this->pd3dDevice->PSSetShader(this->pPixelShader.Get());
    auto *pFontSampler = this->pFontSampler.Get();
    this->pd3dDevice->PSSetSamplers(0, 1, &pFontSampler);
    this->pd3dDevice->GSSetShader(NULL);

    // Setup render state
    const float blend_factor[4] = {0.f, 0.f, 0.f, 0.f};
    this->pd3dDevice->OMSetBlendState(this->pBlendState.Get(), blend_factor, 0xffffffff);
    this->pd3dDevice->OMSetDepthStencilState(this->pDepthStencilState.Get(), 0);
    this->pd3dDevice->RSSetState(this->pRasterizerState.Get());

    for (uintptr_t pBuf = reinterpret_cast<uintptr_t>(data); pBuf < reinterpret_cast<uintptr_t>(data + data_size);
         pBuf += static_cast<uintptr_t>(((RS::dataheader *)pBuf)->size) + sizeof(RS::dataheader)) {

        if (((RS::dataheader *)pBuf)->type == RS::datatype::Unknown) {
            break;
        }

        if (((RS::dataheader *)pBuf)->type == RS::datatype::FunSetScissorRects) {
            RS::DataSetScissorRects *SetScissorRectsPtr = (RS::DataSetScissorRects *)(pBuf + sizeof(RS::dataheader));
            this->pd3dDevice->RSSetScissorRects(SetScissorRectsPtr->NumRects, &(SetScissorRectsPtr->rect.dx10));
        }
        if (((RS::dataheader *)pBuf)->type == RS::datatype::FunSetShaderResources) {
            RS::DataSetShaderResources *SetShaderResourcesPtr =
                (RS::DataSetShaderResources *)(pBuf + sizeof(RS::dataheader));
            auto *pShaderResourceViews = this->pTextureViewMap[SetShaderResourcesPtr->TexID];
            this->pd3dDevice->PSSetShaderResources(
                SetShaderResourcesPtr->StartSlot, SetShaderResourcesPtr->NumViews, &pShaderResourceViews);
        }
        if (((RS::dataheader *)pBuf)->type == RS::datatype::FunDataDrawIndexed) {
            RS::DataDrawIndexed *DrawIndexedPtr = (RS::DataDrawIndexed *)(pBuf + sizeof(RS::dataheader));
            if (bypass::CanPresent())
                this->pd3dDevice->DrawIndexed(
                    DrawIndexedPtr->IndexCount, DrawIndexedPtr->StartIndexLocation, DrawIndexedPtr->BaseVertexLocation);
        }
    }

    this->pd3dDevice->RSSetScissorRects(old.ScissorRectsCount, old.ScissorRects);
    this->pd3dDevice->RSSetViewports(old.ViewportsCount, old.Viewports);
    this->pd3dDevice->RSSetState(old.RS);
    if (old.RS)
        old.RS->Release();
    this->pd3dDevice->OMSetBlendState(old.BlendState, old.BlendFactor, old.SampleMask);
    if (old.BlendState)
        old.BlendState->Release();
    this->pd3dDevice->OMSetDepthStencilState(old.DepthStencilState, old.StencilRef);
    if (old.DepthStencilState)
        old.DepthStencilState->Release();
    this->pd3dDevice->PSSetShaderResources(0, 1, &old.PSShaderResource);
    if (old.PSShaderResource)
        old.PSShaderResource->Release();
    this->pd3dDevice->PSSetSamplers(0, 1, &old.PSSampler);
    if (old.PSSampler)
        old.PSSampler->Release();
    this->pd3dDevice->PSSetShader(old.PS);
    if (old.PS)
        old.PS->Release();
    this->pd3dDevice->VSSetShader(old.VS);
    if (old.VS)
        old.VS->Release();
    this->pd3dDevice->GSSetShader(old.GS);
    if (old.GS)
        old.GS->Release();
    this->pd3dDevice->VSSetConstantBuffers(0, 1, &old.VSConstantBuffer);
    if (old.VSConstantBuffer)
        old.VSConstantBuffer->Release();
    this->pd3dDevice->IASetPrimitiveTopology(old.PrimitiveTopology);
    this->pd3dDevice->IASetIndexBuffer(old.IndexBuffer, old.IndexBufferFormat, old.IndexBufferOffset);
    if (old.IndexBuffer)
        old.IndexBuffer->Release();
    this->pd3dDevice->IASetVertexBuffers(0, 1, &old.VertexBuffer, &old.VertexBufferStride, &old.VertexBufferOffset);
    if (old.VertexBuffer)
        old.VertexBuffer->Release();
    this->pd3dDevice->IASetInputLayout(old.InputLayout);
    if (old.InputLayout)
        old.InputLayout->Release();
}

unsigned char IImDataRender::pixel_shader[832] = {
    68,  88,  66,  67,  156, 131, 174, 203, 172, 47,  184, 213, 201, 80,  81,  217, 17,  39,  38,  74,  1,   0,   0,
    0,   64,  3,   0,   0,   6,   0,   0,   0,   56,  0,   0,   0,   204, 0,   0,   0,   124, 1,   0,   0,   248, 1,
    0,   0,   152, 2,   0,   0,   12,  3,   0,   0,   65,  111, 110, 57,  140, 0,   0,   0,   140, 0,   0,   0,   0,
    2,   255, 255, 100, 0,   0,   0,   40,  0,   0,   0,   0,   0,   40,  0,   0,   0,   40,  0,   0,   0,   40,  0,
    1,   0,   36,  0,   0,   0,   40,  0,   0,   0,   0,   0,   1,   2,   255, 255, 31,  0,   0,   2,   0,   0,   0,
    128, 0,   0,   15,  176, 31,  0,   0,   2,   0,   0,   0,   128, 1,   0,   3,   176, 31,  0,   0,   2,   0,   0,
    0,   144, 0,   8,   15,  160, 66,  0,   0,   3,   0,   0,   15,  128, 1,   0,   228, 176, 0,   8,   228, 160, 5,
    0,   0,   3,   0,   0,   15,  128, 0,   0,   228, 128, 0,   0,   228, 176, 1,   0,   0,   2,   0,   0,   15,  128,
    0,   0,   228, 128, 1,   0,   0,   2,   0,   8,   15,  128, 0,   0,   228, 128, 255, 255, 0,   0,   83,  72,  68,
    82,  168, 0,   0,   0,   64,  0,   0,   0,   42,  0,   0,   0,   90,  0,   0,   3,   0,   96,  16,  0,   0,   0,
    0,   0,   88,  24,  0,   4,   0,   112, 16,  0,   0,   0,   0,   0,   85,  85,  0,   0,   98,  16,  0,   3,   242,
    16,  16,  0,   1,   0,   0,   0,   98,  16,  0,   3,   50,  16,  16,  0,   2,   0,   0,   0,   101, 0,   0,   3,
    242, 32,  16,  0,   0,   0,   0,   0,   104, 0,   0,   2,   1,   0,   0,   0,   69,  0,   0,   9,   242, 0,   16,
    0,   0,   0,   0,   0,   70,  16,  16,  0,   2,   0,   0,   0,   70,  126, 16,  0,   0,   0,   0,   0,   0,   96,
    16,  0,   0,   0,   0,   0,   56,  0,   0,   7,   242, 0,   16,  0,   0,   0,   0,   0,   70,  14,  16,  0,   0,
    0,   0,   0,   70,  30,  16,  0,   1,   0,   0,   0,   54,  0,   0,   5,   242, 32,  16,  0,   0,   0,   0,   0,
    70,  14,  16,  0,   0,   0,   0,   0,   62,  0,   0,   1,   83,  84,  65,  84,  116, 0,   0,   0,   4,   0,   0,
    0,   1,   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   82,  68,
    69,  70,  152, 0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   2,   0,   0,   0,   28,  0,   0,   0,   0,
    4,   255, 255, 4,   1,   0,   0,   110, 0,   0,   0,   92,  0,   0,   0,   3,   0,   0,   0,   0,   0,   0,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,   101, 0,   0,
    0,   2,   0,   0,   0,   5,   0,   0,   0,   4,   0,   0,   0,   255, 255, 255, 255, 0,   0,   0,   0,   1,   0,
    0,   0,   12,  0,   0,   0,   115, 97,  109, 112, 108, 101, 114, 48,  0,   116, 101, 120, 116, 117, 114, 101, 48,
    0,   77,  105, 99,  114, 111, 115, 111, 102, 116, 32,  40,  82,  41,  32,  72,  76,  83,  76,  32,  83,  104, 97,
    100, 101, 114, 32,  67,  111, 109, 112, 105, 108, 101, 114, 32,  49,  48,  46,  49,  0,   171, 171, 73,  83,  71,
    78,  108, 0,   0,   0,   3,   0,   0,   0,   8,   0,   0,   0,   80,  0,   0,   0,   0,   0,   0,   0,   1,   0,
    0,   0,   3,   0,   0,   0,   0,   0,   0,   0,   15,  0,   0,   0,   92,  0,   0,   0,   0,   0,   0,   0,   0,
    0,   0,   0,   3,   0,   0,   0,   1,   0,   0,   0,   15,  15,  0,   0,   98,  0,   0,   0,   0,   0,   0,   0,
    0,   0,   0,   0,   3,   0,   0,   0,   2,   0,   0,   0,   3,   3,   0,   0,   83,  86,  95,  80,  79,  83,  73,
    84,  73,  79,  78,  0,   67,  79,  76,  79,  82,  0,   84,  69,  88,  67,  79,  79,  82,  68,  0,   171, 79,  83,
    71,  78,  44,  0,   0,   0,   1,   0,   0,   0,   8,   0,   0,   0,   32,  0,   0,   0,   0,   0,   0,   0,   0,
    0,   0,   0,   3,   0,   0,   0,   0,   0,   0,   0,   15,  0,   0,   0,   83,  86,  95,  84,  97,  114, 103, 101,
    116, 0,   171, 171};
unsigned char IImDataRender::vertex_shader[1436] = {
    68,  88,  66,  67,  121, 204, 233, 41,  192, 57,  30,  133, 32,  100, 189, 62,  70,  74,  75,  111, 1,   0,   0,
    0,   156, 5,   0,   0,   6,   0,   0,   0,   56,  0,   0,   0,   164, 1,   0,   0,   108, 3,   0,   0,   232, 3,
    0,   0,   184, 4,   0,   0,   40,  5,   0,   0,   65,  111, 110, 57,  100, 1,   0,   0,   100, 1,   0,   0,   0,
    2,   254, 255, 36,  1,   0,   0,   64,  0,   0,   0,   2,   0,   36,  0,   0,   0,   60,  0,   0,   0,   60,  0,
    0,   0,   36,  0,   1,   0,   60,  0,   0,   0,   0,   0,   2,   0,   1,   0,   0,   0,   0,   0,   0,   0,   3,
    0,   1,   0,   3,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   2,   254, 255, 81,  0,   0,   5,   4,   0,
    15,  160, 0,   0,   0,   0,   0,   0,   128, 63,  0,   0,   0,   0,   0,   0,   0,   0,   31,  0,   0,   2,   5,
    0,   0,   128, 0,   0,   15,  144, 31,  0,   0,   2,   5,   0,   1,   128, 1,   0,   15,  144, 31,  0,   0,   2,
    5,   0,   2,   128, 2,   0,   15,  144, 5,   0,   0,   3,   0,   0,   15,  128, 0,   0,   0,   144, 1,   0,   228,
    160, 5,   0,   0,   3,   1,   0,   15,  128, 0,   0,   85,  144, 2,   0,   228, 160, 2,   0,   0,   3,   0,   0,
    15,  128, 0,   0,   228, 128, 1,   0,   228, 128, 2,   0,   0,   3,   0,   0,   15,  128, 0,   0,   228, 128, 4,
    0,   0,   160, 1,   0,   0,   2,   1,   0,   2,   128, 4,   0,   85,  160, 5,   0,   0,   3,   1,   0,   15,  128,
    1,   0,   85,  128, 3,   0,   228, 160, 2,   0,   0,   3,   0,   0,   15,  128, 0,   0,   228, 128, 1,   0,   228,
    128, 1,   0,   0,   2,   1,   0,   15,  128, 1,   0,   228, 144, 1,   0,   0,   2,   2,   0,   3,   128, 2,   0,
    228, 144, 1,   0,   0,   2,   0,   0,   15,  224, 1,   0,   228, 128, 1,   0,   0,   2,   0,   0,   3,   128, 0,
    0,   228, 128, 1,   0,   0,   2,   0,   0,   12,  128, 0,   0,   228, 128, 1,   0,   0,   2,   1,   0,   3,   224,
    2,   0,   228, 128, 5,   0,   0,   3,   1,   0,   3,   128, 0,   0,   255, 128, 0,   0,   228, 160, 2,   0,   0,
    3,   0,   0,   3,   192, 0,   0,   228, 128, 1,   0,   228, 128, 1,   0,   0,   2,   0,   0,   12,  192, 0,   0,
    228, 128, 255, 255, 0,   0,   83,  72,  68,  82,  192, 1,   0,   0,   64,  0,   1,   0,   112, 0,   0,   0,   89,
    0,   0,   4,   70,  142, 32,  0,   0,   0,   0,   0,   4,   0,   0,   0,   95,  0,   0,   3,   50,  16,  16,  0,
    0,   0,   0,   0,   95,  0,   0,   3,   242, 16,  16,  0,   1,   0,   0,   0,   95,  0,   0,   3,   50,  16,  16,
    0,   2,   0,   0,   0,   103, 0,   0,   4,   242, 32,  16,  0,   0,   0,   0,   0,   1,   0,   0,   0,   101, 0,
    0,   3,   242, 32,  16,  0,   1,   0,   0,   0,   101, 0,   0,   3,   50,  32,  16,  0,   2,   0,   0,   0,   104,
    0,   0,   2,   3,   0,   0,   0,   56,  0,   0,   8,   242, 0,   16,  0,   0,   0,   0,   0,   6,   16,  16,  0,
    0,   0,   0,   0,   70,  142, 32,  0,   0,   0,   0,   0,   0,   0,   0,   0,   56,  0,   0,   8,   242, 0,   16,
    0,   1,   0,   0,   0,   86,  21,  16,  0,   0,   0,   0,   0,   70,  142, 32,  0,   0,   0,   0,   0,   1,   0,
    0,   0,   0,   0,   0,   7,   242, 0,   16,  0,   0,   0,   0,   0,   70,  14,  16,  0,   0,   0,   0,   0,   70,
    14,  16,  0,   1,   0,   0,   0,   56,  0,   0,   11,  242, 0,   16,  0,   1,   0,   0,   0,   70,  142, 32,  0,
    0,   0,   0,   0,   2,   0,   0,   0,   2,   64,  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   7,   242, 0,   16,  0,   0,   0,   0,   0,   70,  14,  16,  0,   0,   0,
    0,   0,   70,  14,  16,  0,   1,   0,   0,   0,   56,  0,   0,   11,  242, 0,   16,  0,   1,   0,   0,   0,   70,
    142, 32,  0,   0,   0,   0,   0,   3,   0,   0,   0,   2,   64,  0,   0,   0,   0,   128, 63,  0,   0,   128, 63,
    0,   0,   128, 63,  0,   0,   128, 63,  0,   0,   0,   7,   242, 0,   16,  0,   0,   0,   0,   0,   70,  14,  16,
    0,   0,   0,   0,   0,   70,  14,  16,  0,   1,   0,   0,   0,   54,  0,   0,   5,   242, 0,   16,  0,   1,   0,
    0,   0,   70,  30,  16,  0,   1,   0,   0,   0,   54,  0,   0,   5,   50,  0,   16,  0,   2,   0,   0,   0,   70,
    16,  16,  0,   2,   0,   0,   0,   54,  0,   0,   5,   242, 32,  16,  0,   0,   0,   0,   0,   70,  14,  16,  0,
    0,   0,   0,   0,   54,  0,   0,   5,   242, 32,  16,  0,   1,   0,   0,   0,   70,  14,  16,  0,   1,   0,   0,
    0,   54,  0,   0,   5,   50,  32,  16,  0,   2,   0,   0,   0,   70,  0,   16,  0,   2,   0,   0,   0,   62,  0,
    0,   1,   83,  84,  65,  84,  116, 0,   0,   0,   13,  0,   0,   0,   3,   0,   0,   0,   0,   0,   0,   0,   6,
    0,   0,   0,   7,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   0,   0,   0,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   5,   0,   0,   0,   0,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   82,  68,  69,  70,  200, 0,   0,   0,   1,   0,   0,   0,
    76,  0,   0,   0,   1,   0,   0,   0,   28,  0,   0,   0,   0,   4,   254, 255, 4,   1,   0,   0,   160, 0,   0,
    0,   60,  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    0,   0,   1,   0,   0,   0,   1,   0,   0,   0,   118, 101, 114, 116, 101, 120, 66,  117, 102, 102, 101, 114, 0,
    171, 171, 171, 60,  0,   0,   0,   1,   0,   0,   0,   100, 0,   0,   0,   64,  0,   0,   0,   0,   0,   0,   0,
    0,   0,   0,   0,   124, 0,   0,   0,   0,   0,   0,   0,   64,  0,   0,   0,   2,   0,   0,   0,   144, 0,   0,
    0,   0,   0,   0,   0,   80,  114, 111, 106, 101, 99,  116, 105, 111, 110, 77,  97,  116, 114, 105, 120, 0,   171,
    171, 171, 3,   0,   3,   0,   4,   0,   4,   0,   0,   0,   0,   0,   0,   0,   0,   0,   77,  105, 99,  114, 111,
    115, 111, 102, 116, 32,  40,  82,  41,  32,  72,  76,  83,  76,  32,  83,  104, 97,  100, 101, 114, 32,  67,  111,
    109, 112, 105, 108, 101, 114, 32,  49,  48,  46,  49,  0,   73,  83,  71,  78,  104, 0,   0,   0,   3,   0,   0,
    0,   8,   0,   0,   0,   80,  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,   0,   0,   0,
    0,   0,   3,   3,   0,   0,   89,  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,   0,   1,
    0,   0,   0,   15,  15,  0,   0,   95,  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,   0,
    2,   0,   0,   0,   3,   3,   0,   0,   80,  79,  83,  73,  84,  73,  79,  78,  0,   67,  79,  76,  79,  82,  0,
    84,  69,  88,  67,  79,  79,  82,  68,  0,   79,  83,  71,  78,  108, 0,   0,   0,   3,   0,   0,   0,   8,   0,
    0,   0,   80,  0,   0,   0,   0,   0,   0,   0,   1,   0,   0,   0,   3,   0,   0,   0,   0,   0,   0,   0,   15,
    0,   0,   0,   92,  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,   0,   1,   0,   0,   0,
    15,  0,   0,   0,   98,  0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   3,   0,   0,   0,   2,   0,   0,
    0,   3,   12,  0,   0,   83,  86,  95,  80,  79,  83,  73,  84,  73,  79,  78,  0,   67,  79,  76,  79,  82,  0,
    84,  69,  88,  67,  79,  79,  82,  68,  0,   171};