#pragma once
#include <windows.h>
#include <vector>

namespace bypass {
	bool CanPresent();
};